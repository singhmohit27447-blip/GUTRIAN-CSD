# GUTRIAN CSD

Android card management app.

## Included in v1.5.0
- Admin/viewer roles
- Add, edit, issue, return and permanent delete (admin only)
- Company-wise summary, company details and all-card search
- Card history with operator and timestamps
- Reports and CSV export
- Custom issue reminders from 1 to 3650 days
- Local Android reminder notification at the selected due time
- Returning a card cancels its scheduled reminder
- SMS composer from Card Details (automatic carrier SMS is not claimed)
- Firebase Auth + Firestore

## Build
The GitHub Actions workflow must extract `GUTRIAN_CSD_FINAL_SOURCE_V1_5.zip` and run `:app:assembleDebug`.
