@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.gutrian.csd

import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.*
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import java.text.SimpleDateFormat
import java.util.*

data class CardRecord(
    val id: String = "", val cardNumber: String = "", val name: String = "",
    val phone: String = "", val company: String = "", val department: String = "",
    val status: String = "AVAILABLE", val note: String = ""
)
data class EventRecord(
    val action: String, val cardNumber: String, val name: String, val company: String, val at: Timestamp?
)
data class ManagedUser(val email: String, val role: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme { GutrianCsdApp(this) } }
    }
}

@Composable
fun GutrianCsdApp(activity: ComponentActivity) {
    val auth = remember { FirebaseAuth.getInstance(FirebaseApp.getInstance()) }
    val db = remember { FirebaseFirestore.getInstance(FirebaseApp.getInstance()) }
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("VIEWER") }
    var cards by remember { mutableStateOf(listOf<CardRecord>()) }
    var events by remember { mutableStateOf(listOf<EventRecord>()) }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var needsAdminSetup by remember { mutableStateOf(false) }
    val context = LocalContext.current

    fun toast(s: String) { message = s }
    fun load() {
        val u = auth.currentUser ?: return
        busy = true
        val email = (u.email ?: "").trim().lowercase(Locale.ENGLISH)

        // Force-refresh the Firebase ID token before touching Firestore.
        // This prevents the native app from making Firestore calls with a
        // stale/missing auth token immediately after email login.
        u.getIdToken(true)
            .addOnSuccessListener {
                loadUserAndData(auth, db, u, email, ::toast,
                    { role = it },
                    { cards = it },
                    { events = it },
                    { needsAdminSetup = it },
                    { busy = false })
            }
            .addOnFailureListener {
                busy = false
                role = "VIEWER"
                toast("Firebase login token error: ${it.message ?: "unknown error"}")
            }
    }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { state ->
            user = state.currentUser
        }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }

    LaunchedEffect(user?.uid) { if (user != null) load() }

    if (user == null) {
        EmailLoginScreen(
            busy = busy,
            onLogin = { email, password ->
                if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { toast("Valid email enter karein"); return@EmailLoginScreen }
                if (password.length < 6) { toast("Password kam se kam 6 characters ka hona chahiye"); return@EmailLoginScreen }
                busy = true
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { user = it.user; busy = false }
                    .addOnFailureListener { busy = false; toast(it.message ?: "Login failed") }
            },
            onRegister = { email, password ->
                if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { toast("Valid email enter karein"); return@EmailLoginScreen }
                if (password.length < 6) { toast("Password kam se kam 6 characters ka hona chahiye"); return@EmailLoginScreen }
                busy = true
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { user = it.user; busy = false; toast("Account created") }
                    .addOnFailureListener { busy = false; toast(it.message ?: "Account create failed") }
            },
            onForgot = { email ->
                if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { toast("Pehle valid email enter karein"); return@EmailLoginScreen }
                busy = true
                auth.sendPasswordResetEmail(email.trim())
                    .addOnSuccessListener { busy = false; toast("Password reset email bhej diya gaya") }
                    .addOnFailureListener { busy = false; toast(it.message ?: "Reset email failed") }
            }
        )
    } else {
        Scaffold(topBar = { TopAppBar(title = { Text("GUTRIAN CSD", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = { auth.signOut(); user = null; role = "VIEWER" }) { Text("Logout") } }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    "home" -> Dashboard(cards, role, needsAdminSetup, {
                        val current = auth.currentUser
                        if (current == null) { toast("Please login again"); return@Dashboard }
                        busy = true
                        val email = (current.email ?: "").trim().lowercase(Locale.ENGLISH)
                        val data = mapOf(
                            "email" to email,
                            "role" to "ADMIN",
                            "Role" to "ADMIN",
                            "updatedAt" to FieldValue.serverTimestamp()
                        )
                        db.collection("Users").document(current.uid).set(data, com.google.firebase.firestore.SetOptions.merge())
                            .addOnSuccessListener {
                                if (email.isBlank()) {
                                    role = "ADMIN"; needsAdminSetup = false; busy = false; load()
                                } else {
                                    db.collection("email_roles").document(emailKey(email)).set(mapOf("email" to email, "role" to "ADMIN", "updatedAt" to FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge())
                                        .addOnCompleteListener {
                                            role = "ADMIN"; needsAdminSetup = false; busy = false; toast("Admin setup complete"); load()
                                        }
                                }
                            }
                            .addOnFailureListener { busy = false; toast("Admin setup failed: ${it.message ?: "unknown error"}") }
                    }, { screen = it })
                    "add" -> AddCardScreen(db, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "issue" -> IssueScreen(db, cards, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "return" -> ReturnScreen(db, cards, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "cards" -> CardsScreen(cards)
                    "history" -> HistoryScreen(events)
                    "admins" -> AdminManagementScreen(db, role == "ADMIN", { toast(it) }, { screen = "home" })
                }
                Spacer(Modifier.weight(1f))
                NavigationBar {
                    listOf("home" to "Home", "cards" to "Cards", "history" to "History").forEach { (r, label) ->
                        NavigationBarItem(screen == r, { screen = r }, icon = {}, label = { Text(label) })
                    }
                }
            }
        }
    }
    if (busy) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    if (message.isNotBlank()) { LaunchedEffect(message) { Toast.makeText(context, message, Toast.LENGTH_LONG).show(); message = "" } }
}

private fun emailKey(email: String): String = email.trim().lowercase(Locale.ENGLISH).replace("/", "_slash_")

private fun loadUserAndData(
    auth: FirebaseAuth,
    db: FirebaseFirestore,
    u: FirebaseUser,
    email: String,
    toast: (String) -> Unit,
    setRole: (String) -> Unit,
    setCards: (List<CardRecord>) -> Unit,
    setEvents: (List<EventRecord>) -> Unit,
    setNeedsAdminSetup: (Boolean) -> Unit,
    finished: () -> Unit
) {
    db.collection("Users").document(u.uid).get()
        .addOnSuccessListener { d ->
            val direct = (d.getString("role") ?: d.getString("Role") ?: "").trim().uppercase(Locale.ENGLISH)
            if (direct == "ADMIN" || direct == "VIEWER") {
                setRole(direct)
                setNeedsAdminSetup(false)
                loadData(db, toast, setCards, setEvents, setNeedsAdminSetup, finished)
            } else if (email.isNotBlank()) {
                db.collection("email_roles").document(emailKey(email)).get()
                    .addOnSuccessListener { er ->
                        val assigned = (er.getString("role") ?: "VIEWER").trim().uppercase(Locale.ENGLISH)
                        val finalRole = if (assigned == "ADMIN") "ADMIN" else "VIEWER"
                        setRole(finalRole)
                        setNeedsAdminSetup(false)
                        db.collection("Users").document(u.uid)
                            .set(mapOf("email" to email, "role" to finalRole, "updatedAt" to FieldValue.serverTimestamp()), com.google.firebase.firestore.SetOptions.merge())
                            .addOnCompleteListener {
                                loadData(db, toast, setCards, setEvents, setNeedsAdminSetup, finished)
                            }
                    }
                    .addOnFailureListener {
                        finished()
                        setRole("VIEWER")
                        setNeedsAdminSetup(true)
                        toast("Initial Admin setup required. Dashboard par button use karein.")
                    }
            } else {
                setRole("VIEWER")
                setNeedsAdminSetup(true)
                loadData(db, toast, setCards, setEvents, setNeedsAdminSetup, finished)
            }
        }
        .addOnFailureListener {
            finished()
            setRole("VIEWER")
            setNeedsAdminSetup(false)
            toast("Users/${u.uid} read failed: ${it.message ?: "unknown error"}")
        }
}

private fun loadData(
    db: FirebaseFirestore,
    toast: (String) -> Unit,
    setCards: (List<CardRecord>) -> Unit,
    setEvents: (List<EventRecord>) -> Unit,
    setNeedsAdminSetup: (Boolean) -> Unit,
    finished: () -> Unit
) {
    var cardsDone = false
    var eventsDone = false
    fun doneOne() {
        if (cardsDone && eventsDone) finished()
    }

    db.collection("cards").get()
        .addOnSuccessListener { snap ->
            setCards(snap.documents.map { d ->
                CardRecord(
                    d.id,
                    d.getString("cardNumber") ?: "",
                    d.getString("name") ?: "",
                    d.getString("phone") ?: "",
                    d.getString("company") ?: "",
                    d.getString("department") ?: "",
                    d.getString("status") ?: "AVAILABLE",
                    d.getString("note") ?: ""
                )
            })
            cardsDone = true
            doneOne()
        }
        .addOnFailureListener {
            cardsDone = true
            toast("Cards read failed: ${it.message ?: "unknown error"}")
            doneOne()
        }

    db.collection("card_events").orderBy("at", Query.Direction.DESCENDING).limit(500).get()
        .addOnSuccessListener { snap ->
            setEvents(snap.documents.map { d ->
                EventRecord(
                    d.getString("action") ?: "",
                    d.getString("cardNumber") ?: "",
                    d.getString("name") ?: "",
                    d.getString("company") ?: "",
                    d.getTimestamp("at")
                )
            })
            eventsDone = true
            doneOne()
        }
        .addOnFailureListener {
            eventsDone = true
            toast("History read failed: ${it.message ?: "unknown error"}")
            doneOne()
        }
}

@Composable fun EmailLoginScreen(busy: Boolean, onLogin: (String, String) -> Unit, onRegister: (String, String) -> Unit, onForgot: (String) -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var createMode by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GUTRIAN CSD", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Text("Secure Email Login", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(20.dp))
        OutlinedTextField(email, { email = it }, label = { Text("Email") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Password") }, singleLine = true, modifier = Modifier.fillMaxWidth(), visualTransformation = androidx.compose.ui.text.input.PasswordVisualTransformation())
        Spacer(Modifier.height(14.dp))
        Button({ if (createMode) onRegister(email, password) else onLogin(email, password) }, enabled = !busy, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text(if (createMode) "CREATE ACCOUNT" else "LOGIN") }
        TextButton({ createMode = !createMode }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text(if (createMode) "Already have an account? Login" else "Create new account") }
        if (!createMode) TextButton({ onForgot(email) }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("Forgot password?") }
        Spacer(Modifier.height(8.dp))
        Text("Free login: Email + Password", color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable fun Dashboard(cards: List<CardRecord>, role: String, needsAdminSetup: Boolean, bootstrapAdmin: () -> Unit, nav: (String) -> Unit) {
    val total = cards.size; val available = cards.count { it.status == "AVAILABLE" }; val out = cards.count { it.status == "OUT" }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { Stat("Total", total.toString(), Modifier.weight(1f)); Stat("Available", available.toString(), Modifier.weight(1f)); Stat("Out", out.toString(), Modifier.weight(1f)) } }
        if (needsAdminSetup && role != "ADMIN") {
            item {
                Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("INITIAL ADMIN SETUP", fontWeight = FontWeight.Bold)
                        Text("Is Firebase account ke liye abhi Admin role assign nahi hai. Ye private app ka first-time setup hai.")
                        Button(onClick = bootstrapAdmin, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("SET THIS ACCOUNT AS ADMIN", fontWeight = FontWeight.Bold) }
                    }
                }
            }
        }
        item { if (role == "ADMIN") { Action("➕  ADD CARD", true) { nav("add") }; Action("🔴  ISSUE CARD", false) { nav("issue") }; Action("🔵  RETURN CARD", false) { nav("return") }; Action("👤  MANAGE ADMINS", false) { nav("admins") } } }
        item { Text("Company-wise Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        val groups = cards.groupBy { it.company.ifBlank { "Unknown" } }
        items(groups.entries.toList()) { (company, list) -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(company, fontWeight = FontWeight.Bold); Text("Total ${list.size} · Available ${list.count { it.status == "AVAILABLE" }} · Out ${list.count { it.status == "OUT" }}") } } }
        item { Text("Role: $role", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
@Composable fun Stat(t: String, v: String, m: Modifier) = Card(m) { Column(Modifier.padding(12.dp)) { Text(t); Text(v, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } }
@Composable fun Action(t: String, primary: Boolean, click: () -> Unit) { Button(click, Modifier.fillMaxWidth().height(56.dp)) { Text(t, fontWeight = FontWeight.Bold) } }

@Composable
fun Form(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            TextButton(onClick = back) { Text("BACK") }
        }
        Column(
            Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            content = content
        )
    }
}

@Composable
fun Field(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable fun AddCardScreen(db: FirebaseFirestore, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var number by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }; var dept by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    Form("ADD CARD", back) { if (!admin) { Text("Viewer cannot add cards."); return@Form }; Field("Person Name", name) { name = it }; Field("Mobile Number", phone) { phone = it }; Field("Unique Card Number", number) { number = it }; Field("Company", company) { company = it }; Field("Department", dept) { dept = it }; Field("Remarks", note) { note = it }
        Button({ if (number.isBlank() || company.isBlank()) done("Card number and company required") else db.collection("cards").whereEqualTo("cardNumber", number.trim()).limit(1).get().addOnSuccessListener { if (!it.isEmpty) done("Card number already exists") else { val ref = db.collection("cards").document(); val data = hashMapOf("name" to name.trim(), "phone" to phone.trim(), "cardNumber" to number.trim(), "company" to company.trim(), "department" to dept.trim(), "status" to "AVAILABLE", "note" to note.trim(), "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()); ref.set(data).addOnSuccessListener { db.collection("card_events").add(hashMapOf("cardId" to ref.id, "cardNumber" to number.trim(), "name" to name.trim(), "company" to company.trim(), "action" to "ADD", "at" to FieldValue.serverTimestamp())); done("Card added") } } } }, Modifier.fillMaxWidth()) { Text("SAVE CARD") }
    }
}

@Composable fun IssueScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Form("ISSUE CARD", back) { if (!admin) { Text("Viewer cannot issue cards."); return@Form }; Field("Card Number", number) { number = it }; Field("Person Name", name) { name = it }; Field("Mobile Number", phone) { phone = it }
        Button({ val c = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }; if (c == null) done("Card not found") else if (c.status == "OUT") done("Card already OUT") else { val ref = db.collection("cards").document(c.id); db.runTransaction { tx -> val snap = tx.get(ref); if (snap.getString("status") != "AVAILABLE") throw IllegalStateException("Card is not available"); tx.update(ref, mapOf("status" to "OUT", "name" to name.trim(), "phone" to phone.trim(), "outAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp())); tx.set(db.collection("card_events").document(), mapOf("cardId" to c.id, "cardNumber" to c.cardNumber, "name" to name.trim(), "company" to c.company, "action" to "ISSUE", "at" to FieldValue.serverTimestamp())) }.addOnSuccessListener { done("Card issued") }.addOnFailureListener { done(it.message ?: "Issue failed") } } }, Modifier.fillMaxWidth()) { Text("ISSUE / CARD OUT") }
    }
}

@Composable fun ReturnScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }
    Form("RETURN CARD", back) { if (!admin) { Text("Viewer cannot return cards."); return@Form }; Field("Card Number", number) { number = it }
        Button({ val c = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }; if (c == null) done("Card not found") else if (c.status != "OUT") done("Card is already AVAILABLE") else { val ref = db.collection("cards").document(c.id); db.runTransaction { tx -> val snap = tx.get(ref); if (snap.getString("status") != "OUT") throw IllegalStateException("Card is not OUT"); tx.update(ref, mapOf("status" to "AVAILABLE", "depositAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp(), "reminderDueAt" to null)); tx.set(db.collection("card_events").document(), mapOf("cardId" to c.id, "cardNumber" to c.cardNumber, "name" to (snap.getString("name") ?: ""), "company" to c.company, "action" to "RETURN", "at" to FieldValue.serverTimestamp())) }.addOnSuccessListener { done("Card returned; reminder stopped") }.addOnFailureListener { done(it.message ?: "Return failed") } } }, Modifier.fillMaxWidth()) { Text("RETURN / DEPOSIT") }
    }
}

@Composable fun CardsScreen(cards: List<CardRecord>) {
    var q by remember { mutableStateOf("") }; val list = cards.filter { listOf(it.cardNumber,it.name,it.company,it.department,it.phone).any { x -> x.contains(q, true) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) { OutlinedTextField(q, { q = it }, label = { Text("Search name / card / company / phone") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(list) { c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(c.cardNumber, fontWeight = FontWeight.Bold); Text("${c.name} · ${c.company}"); Text("${c.department} · ${c.status}") } } } } }
}
@Composable fun HistoryScreen(events: List<EventRecord>) { LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { item { Text("History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }; items(events) { e -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(e.action, fontWeight = FontWeight.Bold); Text("${e.cardNumber} · ${e.name} · ${e.company}"); Text(e.at?.toDate()?.let { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(it) } ?: "Pending") } } } } }

@Composable fun AdminManagementScreen(db: FirebaseFirestore, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var users by remember { mutableStateOf(listOf<ManagedUser>()) }
    fun loadUsers() {
        db.collection("email_roles").get().addOnSuccessListener { snap ->
            users = snap.documents.map { ManagedUser(it.getString("email") ?: it.id, it.getString("role") ?: "VIEWER") }.sortedBy { it.email }
        }
    }
    LaunchedEffect(admin) { if (admin) loadUsers() }
    Form("MANAGE USERS", back) {
        if (!admin) { Text("Only Admin can manage users."); return@Form }
        Text("Email address ko ADMIN ya VIEWER role de sakte hain.", style = MaterialTheme.typography.bodySmall)
        Field("Email Address", email) { email = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button({
                val e = email.trim().lowercase(Locale.ENGLISH)
                if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) done("Valid email required") else db.collection("email_roles").document(emailKey(e)).set(mapOf("email" to e, "role" to "ADMIN", "updatedAt" to FieldValue.serverTimestamp())).addOnSuccessListener { done("Admin access assigned. User can login with email/password."); email = ""; loadUsers() }.addOnFailureListener { done(it.message ?: "Could not assign admin") }
            }, Modifier.weight(1f)) { Text("MAKE ADMIN") }
            OutlinedButton({
                val e = email.trim().lowercase(Locale.ENGLISH)
                if (!Patterns.EMAIL_ADDRESS.matcher(e).matches()) done("Valid email required") else db.collection("email_roles").document(emailKey(e)).set(mapOf("email" to e, "role" to "VIEWER", "updatedAt" to FieldValue.serverTimestamp())).addOnSuccessListener { done("Viewer access assigned."); email = ""; loadUsers() }.addOnFailureListener { done(it.message ?: "Could not change role") }
            }, Modifier.weight(1f)) { Text("MAKE VIEWER") }
        }
        Spacer(Modifier.height(10.dp)); Text("Assigned accounts", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        users.forEach { u -> Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(u.email); Text(u.role, fontWeight = FontWeight.Bold) } } }
    }
}
