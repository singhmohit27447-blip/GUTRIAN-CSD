# GUTRIAN CSD Android

Version 1.3.0

Prototype-aligned mobile card management app.

Included: Home, Companies, Company Details, Card Details, Add, Issue, Return, All Cards search/filter, History, Reports/CSV share, Settings, Admin management, permanent Admin-only card deletion with audit event, duplicate-card protection, Add/Issue/Return success navigation to Home, Firebase Auth/Firestore.

SMS: Card Details provides a pre-filled SMS action using the phone's messaging app. Fully silent automatic SMS requires an appropriate Android SMS implementation/provider and Play policy review; this build does not falsely claim silent SMS delivery.
