plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
    id("com.google.gms.google-services")
}

android { namespace = "com.gutrian.csd"; compileSdk = 35
    defaultConfig { applicationId = "com.gutrian.csd"; minSdk = 26; targetSdk = 35; versionCode = 2; versionName = "1.0.1" }
}

dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("com.google.firebase:firebase-auth:23.2.0")
    implementation("com.google.firebase:firebase-firestore:25.1.1")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
