package com.gutrian.csd

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import java.text.SimpleDateFormat
import java.util.*

private data class CardRecord(
    val id: String = "", val cardNumber: String = "", val name: String = "",
    val phone: String = "", val company: String = "", val department: String = "",
    val status: String = "AVAILABLE", val note: String = ""
)
private data class EventRecord(
    val action: String, val cardNumber: String, val name: String, val company: String, val at: Timestamp?
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        initFirebase()
        setContent { MaterialTheme { GutrianCsdApp() } }
    }
    private fun initFirebase() {
        if (FirebaseApp.getApps(this).isNotEmpty()) return
        val options = FirebaseOptions.Builder()
            .setApiKey("AIzaSyD6xLYqrJUU6Mi_mx3A6I3A9lI6TiyCw98")
            .setApplicationId("1:477244925151:web:79b20a5dfa0f7bddb7356a")
            .setProjectId("card-flow-manger")
            .setGcmSenderId("477244925151")
            .build()
        FirebaseApp.initializeApp(this, options)
    }
}

@Composable
fun GutrianCsdApp() {
    val auth = remember { FirebaseAuth.getInstance() }
    val db = remember { FirebaseFirestore.getInstance() }
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("VIEWER") }
    var cards by remember { mutableStateOf(listOf<CardRecord>()) }
    var events by remember { mutableStateOf(listOf<EventRecord>()) }
    var screen by remember { mutableStateOf("home") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    val context = LocalContext.current

    fun toast(s: String) { message = s }
    fun load() {
        val u = auth.currentUser ?: return
        busy = true
        db.collection("Users").document(u.uid).get().addOnSuccessListener { d -> role = d.getString("role") ?: "VIEWER" }
        db.collection("cards").get().addOnSuccessListener { snap ->
            cards = snap.documents.map { d -> CardRecord(d.id, d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("company") ?: "", d.getString("department") ?: "", d.getString("status") ?: "AVAILABLE", d.getString("note") ?: "") }
            busy = false
        }.addOnFailureListener { busy = false; toast(it.message ?: "Cards load failed") }
        db.collection("card_events").orderBy("at", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(500).get().addOnSuccessListener { snap ->
            events = snap.documents.map { d -> EventRecord(d.getString("action") ?: "", d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("company") ?: "", d.getTimestamp("at")) }
        }
    }
    LaunchedEffect(user?.uid) { if (user != null) load() }

    if (user == null) {
        LoginScreen { email, password ->
            busy = true
            auth.signInWithEmailAndPassword(email.trim(), password).addOnSuccessListener { user = it.user; busy = false }.addOnFailureListener { busy = false; toast(it.message ?: "Login failed") }
        }
    } else {
        Scaffold(topBar = { TopAppBar(title = { Text("GUTRIAN CSD", fontWeight = FontWeight.Bold) }, actions = { TextButton(onClick = { auth.signOut(); user = null }) { Text("Logout") } }) }) { pad ->
            Column(Modifier.padding(pad).fillMaxSize()) {
                when (screen) {
                    "home" -> Dashboard(cards, role, { screen = it })
                    "add" -> AddCardScreen(db, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "issue" -> IssueScreen(db, cards, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "return" -> ReturnScreen(db, cards, role == "ADMIN", { toast(it); load() }, { screen = "home" })
                    "cards" -> CardsScreen(cards) { screen = "return" }
                    "history" -> HistoryScreen(events)
                }
                Spacer(Modifier.weight(1f))
                NavigationBar { listOf("home" to "Home", "cards" to "Cards", "history" to "History").forEach { (r, label) -> NavigationBarItem(screen == r, { screen = r }, icon = {}, label = { Text(label) }) } }
            }
        }
    }
    if (busy) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    if (message.isNotBlank()) { LaunchedEffect(message) { Toast.makeText(context, message, Toast.LENGTH_LONG).show(); message = "" } }
}

@Composable fun LoginScreen(onLogin: (String, String) -> Unit) {
    var email by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center) {
        Text("GUTRIAN CSD", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Card Management System")
        Spacer(Modifier.height(24.dp)); OutlinedTextField(email, { email = it }, label = { Text("Email") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(10.dp)); OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(16.dp)); Button({ if (email.isNotBlank() && pass.isNotBlank()) onLogin(email, pass) }, Modifier.fillMaxWidth().height(52.dp)) { Text("LOGIN") }
    }
}

@Composable fun Dashboard(cards: List<CardRecord>, role: String, nav: (String) -> Unit) {
    val total = cards.size; val available = cards.count { it.status == "AVAILABLE" }; val out = cards.count { it.status == "OUT" }
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { Stat("Total", total.toString(), Modifier.weight(1f)); Stat("Available", available.toString(), Modifier.weight(1f)); Stat("Out", out.toString(), Modifier.weight(1f)) } }
        item { Action("➕  ADD CARD", true) { nav("add") }; Action("🔴  ISSUE CARD", false) { nav("issue") }; Action("🔵  RETURN CARD", false) { nav("return") } }
        item { Text("Company-wise Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold) }
        val groups = cards.groupBy { it.company.ifBlank { "Unknown" } }
        items(groups.entries.toList()) { (company, list) -> Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Row(Modifier.padding(14.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(company, fontWeight = FontWeight.Bold); Text("Total ${list.size} · Available ${list.count { it.status == "AVAILABLE" }} · Out ${list.count { it.status == "OUT" }}") } } }
        item { Text("Role: $role", color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}
@Composable fun Stat(t: String, v: String, m: Modifier) = Card(m) { Column(Modifier.padding(12.dp)) { Text(t); Text(v, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold) } }
@Composable fun Action(t: String, primary: Boolean, click: () -> Unit) { Button(click, Modifier.fillMaxWidth().height(56.dp), colors = if (primary) ButtonDefaults.buttonColors() else ButtonDefaults.buttonColors()) { Text(t, fontWeight = FontWeight.Bold) } }

@Composable fun AddCardScreen(db: FirebaseFirestore, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var number by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }; var dept by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    Form("ADD CARD", back) { if (!admin) { Text("Viewer cannot add cards."); return@Form }; Field("Person Name", name) { name = it }; Field("Mobile Number", phone) { phone = it }; Field("Unique Card Number", number) { number = it }; Field("Company", company) { company = it }; Field("Department", dept) { dept = it }; Field("Remarks", note) { note = it }
        Button({ if (number.isBlank() || company.isBlank()) done("Card number and company required") else db.collection("cards").whereEqualTo("cardNumber", number.trim()).limit(1).get().addOnSuccessListener { if (!it.isEmpty) done("Card number already exists") else { val ref = db.collection("cards").document(); val data = hashMapOf("name" to name.trim(), "phone" to phone.trim(), "cardNumber" to number.trim(), "company" to company.trim(), "department" to dept.trim(), "status" to "AVAILABLE", "note" to note.trim(), "createdAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp()); ref.set(data).addOnSuccessListener { db.collection("card_events").add(hashMapOf("cardId" to ref.id, "cardNumber" to number.trim(), "name" to name.trim(), "company" to company.trim(), "action" to "ADD", "at" to FieldValue.serverTimestamp())); done("Card added") } } } }, Modifier.fillMaxWidth()) { Text("SAVE CARD") }
    }
}

@Composable fun IssueScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }
    Form("ISSUE CARD", back) { if (!admin) { Text("Viewer cannot issue cards."); return@Form }; Field("Card Number", number) { number = it }; Field("Person Name", name) { name = it }; Field("Mobile Number", phone) { phone = it }
        Button({ val c = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }; if (c == null) done("Card not found") else if (c.status == "OUT") done("Card already OUT") else { val ref = db.collection("cards").document(c.id); db.runTransaction { tx -> val snap = tx.get(ref); if (snap.getString("status") != "AVAILABLE") throw IllegalStateException("Card is not available"); tx.update(ref, mapOf("status" to "OUT", "name" to name.trim(), "phone" to phone.trim(), "outAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp())); tx.set(db.collection("card_events").document(), mapOf("cardId" to c.id, "cardNumber" to c.cardNumber, "name" to name.trim(), "company" to c.company, "action" to "ISSUE", "at" to FieldValue.serverTimestamp())) }.addOnSuccessListener { done("Card issued") }.addOnFailureListener { done(it.message ?: "Issue failed") } } }, Modifier.fillMaxWidth()) { Text("ISSUE / CARD OUT") }
    }
}

@Composable fun ReturnScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }
    Form("RETURN CARD", back) { if (!admin) { Text("Viewer cannot return cards."); return@Form }; Field("Card Number", number) { number = it }
        Button({ val c = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }; if (c == null) done("Card not found") else if (c.status != "OUT") done("Card is already AVAILABLE") else { val ref = db.collection("cards").document(c.id); db.runTransaction { tx -> val snap = tx.get(ref); if (snap.getString("status") != "OUT") throw IllegalStateException("Card is not OUT"); tx.update(ref, mapOf("status" to "AVAILABLE", "depositAt" to FieldValue.serverTimestamp(), "updatedAt" to FieldValue.serverTimestamp())); tx.set(db.collection("card_events").document(), mapOf("cardId" to c.id, "cardNumber" to c.cardNumber, "name" to (snap.getString("name") ?: ""), "company" to c.company, "action" to "RETURN", "at" to FieldValue.serverTimestamp())) }.addOnSuccessListener { done("Card returned") }.addOnFailureListener { done(it.message ?: "Return failed") } } }, Modifier.fillMaxWidth()) { Text("RETURN / DEPOSIT") }
    }
}

@Composable fun CardsScreen(cards: List<CardRecord>, onReturn: () -> Unit) {
    var q by remember { mutableStateOf("") }; val list = cards.filter { listOf(it.cardNumber,it.name,it.company,it.department,it.phone).any { x -> x.contains(q, true) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) { OutlinedTextField(q, { q = it }, label = { Text("Search name / card / company / phone") }, modifier = Modifier.fillMaxWidth()); Spacer(Modifier.height(12.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(list) { c -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) { Text(c.cardNumber, fontWeight = FontWeight.Bold); Text("${c.name} · ${c.company}"); Text("${c.department} · ${c.status}") } } } } }
}
@Composable fun HistoryScreen(events: List<EventRecord>) { LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { item { Text("History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }; items(events) { e -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(e.action, fontWeight = FontWeight.Bold); Text("${e.cardNumber} · ${e.name} · ${e.company}"); Text(e.at?.toDate()?.let { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(it) } ?: "Pending") } } } } }

@Composable fun Form(title: String, back: () -> Unit, content: @Composable ColumnScope.() -> Unit) { Column(Modifier.fillMaxSize().padding(16.dp)) { Row(verticalAlignment = Alignment.CenterVertically) { TextButton(back) { Text("← Back") }; Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }; Spacer(Modifier.height(10.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), content = { item { Column(content = content) } }) } }
@Composable fun Field(label: String, value: String, change: (String) -> Unit) { OutlinedTextField(value, change, label = { Text(label) }, modifier = Modifier.fillMaxWidth()) }
