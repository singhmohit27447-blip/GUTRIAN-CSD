# GUTRIAN CSD — Free Email Login

This version uses Firebase Email/Password authentication. Phone OTP/SMS is intentionally removed so Firebase billing is not required for login.

Firebase project: card-flow-manger

Features included:
- Email/password login and account creation
- Forgot password
- Admin / Viewer role model
- Admin management through email_roles collection
- Card add, issue, return
- Company/department/card/person search
- Dashboard totals and company summary
- Card event history
- Firestore backend

Important first-time setup:
1. Firebase Authentication -> Sign-in method -> enable Email/Password.
2. Keep the existing Users collection. The first admin must already have a Users/{UID} document with role=ADMIN.
3. Publish firestore.rules from this package in Firebase Console -> Firestore Database -> Rules.
4. Admin can then assign ADMIN or VIEWER roles by email from the app.
