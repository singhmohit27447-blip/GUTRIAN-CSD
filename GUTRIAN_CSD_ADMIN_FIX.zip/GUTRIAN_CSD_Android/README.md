# GUTRIAN CSD — Android V1

Native Android app for card issue/return management.

## V1 working features
- Firebase Email/Password login
- Admin/Viewer role check from `Users/{uid}.role`
- Dashboard: Total / Available / Out + company summary
- Add Card
- Issue / Card Out with Firestore transaction
- Return / Deposit with Firestore transaction
- Search by card, name, company, department, phone
- Event history
- Firestore cloud sync and Android Firestore offline cache
- GitHub Actions workflow that builds an APK

## Firebase
Uses the existing Firebase project `card-flow-manger` and the existing web Firebase configuration. The app expects the same Firestore collections: `cards`, `card_events`, and `Users`.

The currently published Firestore rules should allow authenticated readers and ADMIN writers. Before Play Store production, tighten the rules further and add App Check, release signing, notification/reminder backend, and privacy policy.

## Build from phone with GitHub
1. Upload this project to the `GUTRIAN-CSD` GitHub repository (or a new repository).
2. Open **Actions** → **Build GUTRIAN CSD APK** → **Run workflow**.
3. Open the completed workflow run → **Artifacts** → `GUTRIAN-CSD-debug`.
4. Download the APK on Android and install it.

This produces an actual APK; the ZIP itself is source code and is not directly installable.
