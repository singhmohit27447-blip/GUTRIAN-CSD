# CSD Card Management — branch-isolation preview v2.0

Android application source built with Kotlin, Jetpack Compose, Firebase Authentication and Cloud Firestore.

## Implemented in this preview
- App label and primary branding changed to **CSD Card Management** with blue/white styling.
- Removed the hard-coded global Main Admin email bypass.
- New account creates an independent root branch and first branch Admin membership.
- Card and card-history reads are filtered by the signed-in user's `branchId`.
- New cards and all add/edit/issue/return/delete history events carry `branchId`.
- Card-number duplicate checks are branch-scoped.
- Admin role invitations are scoped to the current branch; invited users must verify their email before membership is provisioned.
- Parent Admin can create direct sub-branches, switch among its branch/descendants, and invite Admin/Viewer users to a selected branch. Child branches do not gain access to parent or sibling data.
- Strict Firestore rules and a composite index configuration are included.

## Critical status: preview, not production-ready
This source has **not** been built with the Android Gradle toolchain in this environment, and the Firestore rules have **not** been validated in the Firebase Emulator Suite. Do not deploy these rules or publish this APK/source as production-ready without the acceptance tests in `BRANCH_SECURITY_TEST_PLAN.md`.

The new sub-branch interface and rules have not yet been validated by a full Android build or Firebase Emulator tests. Existing Firestore records without `branchId` will be denied by the strict rules; export and explicitly migrate them to the correct branch before enabling the rules.

## Firebase setup
- Firebase Android package: `com.gutrian.csd`.
- Enable Email/Password authentication.
- Collections: `branches`, `Users`, `cards`, `card_events`, `email_roles`.
- `firestore.rules` and `firestore.indexes.json` are included. Validate them in Firebase Emulator Suite before deployment.
- Keep a backup of Firestore before any migration. Do not use the old permissive rules with branch data.

## Build and Play Store
The previous GitHub Actions workflow builds a **debug APK** only. A Play Store release requires a clean CI build, security tests, signed Android App Bundle (`.aab`), privacy policy, Data Safety form, store listing and any applicable closed testing. No release AAB is included in this ZIP.

## Limitations
- Reminder notifications are scheduled locally on a device; there is no guaranteed cross-device backend scheduler.
- The SMS action opens the phone's SMS composer; it does not send automatic SMS.
- Safe migration of existing records, emulator tests, a clean Android CI build and signed release packaging remain unfinished.
