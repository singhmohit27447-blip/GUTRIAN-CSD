# Required branch-isolation acceptance tests

Run these against Firebase Emulator Suite before deploying the rules. The source has not yet passed these integration tests.

1. Branch A Admin can read/write only documents with `branchId = A`.
2. Branch B Admin cannot read, edit or delete any card in A, and cannot read A's history or invitations.
3. A Viewer can read their own branch but cannot create/update/delete cards or write history.
4. An invited email cannot join the branch before email verification; after verification, its `Users/{uid}` membership is created from the matching invitation.
5. A user cannot edit their own role or `branchId`, create a membership in an arbitrary existing branch, or overwrite another user's membership.
6. `card_events` cannot be updated or deleted after creation.
7. Card duplicate checks are scoped to a branch; the same card number may exist in two independent branches.
8. A disabled member cannot read any branch data.
9. Existing legacy documents without `branchId` are denied under strict rules; back them up and migrate them explicitly before production rollout.
10. Verify offline writes sync after reconnect and no records from another branch appear after sign-out/sign-in.

Known remaining work before a production release: branch/sub-branch selection and management UI; tested data migration for old records; Firebase Emulator tests; full Android CI build; signed release AAB; Play Store privacy/Data Safety materials. Do not claim production readiness until these pass.
