from pathlib import Path
import re, sys
root=Path(__file__).resolve().parent
s=(root/'app/src/main/java/com/gutrian/csd/MainActivity.kt').read_text()
r=(root/'firestore.rules').read_text()
checks={
 'no hard-coded global admin': 'ADMIN_EMAIL' not in s and 'gutrian-csd@gmail.com' not in s,
 'cards read scoped by branch': 'collection("cards").whereEqualTo("branchId", activeBranchId).get()' in s,
 'history read scoped by branch': 'collection("card_events").whereEqualTo("branchId", activeBranchId)' in s,
 'new cards include branchId': 'mapOf("branchId" to activeBranchId,"name"' in s,
 'branch-scoped invite queries': 'collection("email_roles").whereEqualTo("branchId", targetBranchId)' in s,
 'rules require active branch membership': 'function activeMember()' in r and 'me().branchId is string' in r,
 'rules deny event mutation': 'allow update, delete: if false;' in r,
 'app label updated': 'android:label="CSD Card Management"' in (root/'app/src/main/AndroidManifest.xml').read_text(),
 'index file present': (root/'firestore.indexes.json').exists(),
 'sub-branch creation UI present': 'CREATE SUB-BRANCH' in s,
 'branch selector present': 'Active branch' in s and 'whereArrayContains("ancestorIds", membershipBranchId)' in s,
 'branch hierarchy rule present': 'canManageBranch(request.resource.data.parentBranchId)' in r,
}
for name, ok in checks.items(): print(('PASS' if ok else 'FAIL')+' - '+name)
if not all(checks.values()): sys.exit(1)
