@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.gutrian.csd

import android.os.Bundle
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import android.content.Intent
import android.net.Uri
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.*

private var membershipBranchId: String = ""
private var activeBranchId: String = ""
private var activeBranchName: String = ""
private var activeBranchAncestors: List<String> = emptyList()
private val Purple = Color(0xFF1769AA)
private val LightBg = Color(0xFFF6FAFF)

data class CardRecord(
    val id: String = "", val cardNumber: String = "", val name: String = "",
    val phone: String = "", val company: String = "", val department: String = "",
    val status: String = "AVAILABLE", val note: String = "", val reminderDueAt: Timestamp? = null
)
data class EventRecord(
    val id: String = "", val action: String = "", val cardId: String = "", val cardNumber: String = "",
    val name: String = "", val company: String = "", val by: String = "", val at: Timestamp? = null
)
data class ManagedUser(val email: String, val role: String)
data class CompanySummary(val name: String, val total: Int, val available: Int, val out: Int)

enum class AppScreen { HOME, COMPANIES, COMPANY, CARD, ALL_CARDS, ADD, EDIT, ISSUE, RETURN, HISTORY, REPORTS, ADMINS, SETTINGS }

private const val REMINDER_CHANNEL_ID = "gutrian_card_reminders"

private fun reminderRequestCode(cardId: String): Int = cardId.hashCode() and 0x7fffffff

private fun createReminderChannel(context: Context) {
    if (android.os.Build.VERSION.SDK_INT >= 26) {
        val channel = NotificationChannel(
            REMINDER_CHANNEL_ID,
            "CSD Card Management Reminders",
            NotificationManager.IMPORTANCE_HIGH
        ).apply { description = "Reminders for cards that are still issued/out" }
        context.getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }
}

private fun scheduleCardReminder(context: Context, cardId: String, cardNumber: String, holderName: String, due: Timestamp) {
    createReminderChannel(context)
    val intent = Intent(context, CardReminderReceiver::class.java).apply {
        putExtra("cardId", cardId)
        putExtra("cardNumber", cardNumber)
        putExtra("holderName", holderName)
    }
    val pending = PendingIntent.getBroadcast(
        context, reminderRequestCode(cardId), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due.toDate().time, pending)
}

private fun cancelCardReminder(context: Context, cardId: String) {
    val intent = Intent(context, CardReminderReceiver::class.java)
    val pending = PendingIntent.getBroadcast(
        context, reminderRequestCode(cardId), intent,
        PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    alarm.cancel(pending)
    pending.cancel()
}

class CardReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        createReminderChannel(context)
        val cardNumber = intent.getStringExtra("cardNumber") ?: "Card"
        val holderName = intent.getStringExtra("holderName") ?: "holder"
        val launch = context.packageManager.getLaunchIntentForPackage(context.packageName)
        val contentIntent = launch?.let {
            PendingIntent.getActivity(
                context, 9000, it,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
        }
        val notification = NotificationCompat.Builder(context, REMINDER_CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("CSD Card Management — Card Reminder")
            .setContentText("Card $cardNumber issued to $holderName is still OUT.")
            .setStyle(NotificationCompat.BigTextStyle().bigText("Card $cardNumber issued to $holderName is still OUT. Please check and arrange return."))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .apply { if (contentIntent != null) setContentIntent(contentIntent) }
            .build()
        if (android.os.Build.VERSION.SDK_INT < 33 ||
            context.checkSelfPermission("android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED) {
            context.getSystemService(NotificationManager::class.java).notify(reminderRequestCode(cardNumber), notification)
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        createReminderChannel(this)
        if (android.os.Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission("android.permission.POST_NOTIFICATIONS") != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 7001)
        }
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = LightBg)) { GutrianCsdApp() } }
    }
}

@Composable
fun GutrianCsdApp() {
    val auth = remember { FirebaseAuth.getInstance(FirebaseApp.getInstance()) }
    val db = remember { FirebaseFirestore.getInstance(FirebaseApp.getInstance()) }
    val context = LocalContext.current
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("VIEWER") }
    var cards by remember { mutableStateOf(listOf<CardRecord>()) }
    var events by remember { mutableStateOf(listOf<EventRecord>()) }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    var selectedCompany by remember { mutableStateOf("") }
    var selectedCard by remember { mutableStateOf<CardRecord?>(null) }
    var busy by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }

    fun show(s: String) { toast = s }
    fun reload() {
        val u = auth.currentUser ?: return
        busy = true
        val email = (u.email ?: "").trim().lowercase(Locale.ENGLISH)
        u.getIdToken(true).addOnSuccessListener {
            resolveRole(db, u, email,
                { role = it },
                { loadData(db, { cards = it }, { events = it }, { busy = false }, ::show) },
                { busy = false; show(it) })
        }.addOnFailureListener { busy = false; show(it.message ?: "Login token failed") }
    }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    LaunchedEffect(user?.uid) { if (user != null) reload() }

    if (user == null) {
        EmailLoginScreen(busy, ::show,
            { email, password ->
                busy = true
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { user = it.user; busy = false }
                    .addOnFailureListener { busy = false; show(it.message ?: "Login failed") }
            },
            { email, password, branchName ->
                busy = true
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { result ->
                        val newUser = result.user
                        if (newUser == null) { busy = false; show("Account created but user session missing"); return@addOnSuccessListener }
                        val emailKeyValue = emailKey(email)
                        db.collection("email_roles").document(emailKeyValue).get().addOnSuccessListener { invite ->
                            val invitedBranch = invite.getString("branchId") ?: ""
                            if (invite.exists() && invitedBranch.isNotBlank()) {
                                newUser.sendEmailVerification().addOnCompleteListener { verification ->
                                    auth.signOut(); user = null; busy = false
                                    if (verification.isSuccessful) show("Invitation found. Email verify karein, phir login karein to join your branch.")
                                    else show("Invitation found, but verification email failed: ${verification.exception?.message ?: "try again"}")
                                }
                            } else {
                                val branchRef = db.collection("branches").document()
                                val userRef = db.collection("Users").document(newUser.uid)
                                val branchData = mapOf("name" to branchName, "ownerUid" to newUser.uid, "createdBy" to newUser.uid, "parentBranchId" to "", "ancestorIds" to emptyList<String>(), "active" to true, "createdAt" to FieldValue.serverTimestamp())
                                val memberData = mapOf("email" to email.trim().lowercase(Locale.ENGLISH), "role" to "ADMIN", "branchId" to branchRef.id, "active" to true, "createdAt" to FieldValue.serverTimestamp())
                                db.runBatch { batch -> batch.set(branchRef, branchData); batch.set(userRef, memberData) }
                                    .addOnSuccessListener { activeBranchId = branchRef.id; activeBranchName = branchName; user = newUser; busy = false; show("Branch created successfully") }
                                    .addOnFailureListener { auth.signOut(); user = null; busy = false; show("Branch setup failed: ${it.message ?: "unknown"}") }
                            }
                        }.addOnFailureListener { auth.signOut(); user = null; busy = false; show("Invitation check failed: ${it.message ?: "unknown"}") }
                    }
                    .addOnFailureListener { busy = false; show(it.message ?: "Account create failed") }
            },
            { email ->
                busy = true
                auth.sendPasswordResetEmail(email.trim())
                    .addOnSuccessListener { busy = false; show("Password reset email sent") }
                    .addOnFailureListener { busy = false; show(it.message ?: "Reset failed") }
            })
    } else {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("CSD Card Management", fontWeight = FontWeight.Bold) }, actions = {
                    TextButton(onClick = { auth.signOut(); user = null; membershipBranchId = ""; activeBranchId = ""; activeBranchName = ""; activeBranchAncestors = emptyList() }) { Text("Logout") }
                })
            },
            bottomBar = {
                if (screen !in listOf(AppScreen.ADD, AppScreen.ISSUE, AppScreen.RETURN, AppScreen.COMPANY, AppScreen.CARD, AppScreen.COMPANIES, AppScreen.ALL_CARDS, AppScreen.ADMINS)) {
                    NavigationBar {
                        NavigationBarItem(screen == AppScreen.HOME, { screen = AppScreen.HOME }, icon = { Text("⌂") }, label = { Text("Home") })
                        NavigationBarItem(screen == AppScreen.HISTORY, { screen = AppScreen.HISTORY }, icon = { Text("◷") }, label = { Text("History") })
                        NavigationBarItem(screen == AppScreen.REPORTS, { screen = AppScreen.REPORTS }, icon = { Text("▥") }, label = { Text("Reports") })
                        NavigationBarItem(screen == AppScreen.SETTINGS, { screen = AppScreen.SETTINGS }, icon = { Text("⚙") }, label = { Text("Settings") })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when (screen) {
                    AppScreen.HOME -> HomeScreen(cards, role, { screen = AppScreen.ADD }, { screen = AppScreen.ISSUE }, { screen = AppScreen.RETURN }, { screen = AppScreen.COMPANIES }, { q -> selectedCard = q; screen = AppScreen.CARD }, { screen = AppScreen.ADMINS }, { screen = AppScreen.ALL_CARDS })
                    AppScreen.COMPANIES -> CompaniesScreen(cards, { screen = AppScreen.HOME }, { selectedCompany = it; screen = AppScreen.COMPANY })
                    AppScreen.COMPANY -> CompanyScreen(selectedCompany, cards.filter { it.company.equals(selectedCompany, true) }, { screen = AppScreen.COMPANIES }, { selectedCard = it; screen = AppScreen.CARD })
                    AppScreen.CARD -> CardDetailsScreen(cards.firstOrNull { it.id == selectedCard?.id } ?: selectedCard, events.filter { it.cardId == selectedCard?.id }, { screen = AppScreen.HOME }, role == "ADMIN", db, { show(it); reload() }, { screen = AppScreen.EDIT })
                    AppScreen.ALL_CARDS -> AllCardsScreen(cards, { screen = AppScreen.HOME }, { selectedCard = it; screen = AppScreen.CARD })
                    AppScreen.ADD -> AddCardScreen(db, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.EDIT -> EditCardScreen(db, cards.firstOrNull { it.id == selectedCard?.id } ?: selectedCard, role == "ADMIN", { show(it); reload(); screen = AppScreen.CARD }, { screen = AppScreen.CARD })
                    AppScreen.ISSUE -> IssueScreen(db, cards, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.RETURN -> ReturnScreen(db, cards, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.HISTORY -> HistoryScreen(events) { ev -> selectedCard = cards.firstOrNull { it.id == ev.cardId }; screen = AppScreen.CARD }
                    AppScreen.REPORTS -> ReportsScreen(cards)
                    AppScreen.ADMINS -> AdminManagementScreen(db, role == "ADMIN", { show(it); reload() }, { screen = AppScreen.HOME })
                    AppScreen.SETTINGS -> SettingsScreen(db, user?.email ?: "", role, { screen = AppScreen.ADMINS }, { screen = AppScreen.ALL_CARDS }) { selectedId, selectedName, ancestors -> activeBranchId = selectedId; activeBranchName = selectedName; activeBranchAncestors = ancestors; reload() }
                }
            }
        }
    }

    if (busy) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    if (toast.isNotBlank()) {
        LaunchedEffect(toast) { Toast.makeText(context, toast, Toast.LENGTH_LONG).show(); toast = "" }
    }
}

private fun resolveRole(db: FirebaseFirestore, u: FirebaseUser, email: String, setRole: (String) -> Unit, loaded: () -> Unit, failed: (String) -> Unit) {
    db.collection("Users").document(u.uid).get().addOnSuccessListener { d ->
        fun openMembership(member: com.google.firebase.firestore.DocumentSnapshot) {
            val direct = (member.getString("role") ?: "").uppercase(Locale.ENGLISH)
            val branchId = member.getString("branchId") ?: ""
            if (member.exists() && member.getBoolean("active") == true && branchId.isNotBlank() && (direct == "ADMIN" || direct == "VIEWER")) {
                membershipBranchId = branchId
                db.collection("branches").document(branchId).get().addOnSuccessListener { branch ->
                    if (!branch.exists() || branch.getBoolean("active") != true) { failed("Branch inactive or not found. Contact your branch Admin."); return@addOnSuccessListener }
                    val selected = if (activeBranchId.isNotBlank()) activeBranchId else branchId
                    db.collection("branches").document(selected).get().addOnSuccessListener { selectedDoc ->
                        val selectedAncestors = (selectedDoc.get("ancestorIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                        if (selectedDoc.exists() && selectedDoc.getBoolean("active") == true && (selected == branchId || selectedAncestors.contains(branchId))) {
                            activeBranchId = selected
                            activeBranchName = selectedDoc.getString("name") ?: "My Branch"
                            activeBranchAncestors = selectedAncestors
                        } else {
                            activeBranchId = branchId
                            activeBranchName = branch.getString("name") ?: "My Branch"
                            activeBranchAncestors = (branch.get("ancestorIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                        }
                        setRole(direct); loaded()
                    }.addOnFailureListener { failed("Selected branch read failed: ${it.message ?: "unknown"}") }
                }
            } else failed("This account has no active branch membership. Create a branch account or ask your branch Admin for an invitation.")
        }
        if (d.exists()) { openMembership(d); return@addOnSuccessListener }
        db.collection("email_roles").document(emailKey(email)).get().addOnSuccessListener { invite ->
            if (!invite.exists()) { failed("No branch membership found. Create a new branch account."); return@addOnSuccessListener }
            if (u.isEmailVerified.not()) { failed("Invitation accepted only after email verification. Check your inbox, verify, then login again."); return@addOnSuccessListener }
            val branchId = invite.getString("branchId") ?: ""
            val invitedEmail = (invite.getString("email") ?: "").lowercase(Locale.ENGLISH)
            val invitedRole = (invite.getString("role") ?: "VIEWER").uppercase(Locale.ENGLISH)
            if (branchId.isBlank() || invitedEmail != email.lowercase(Locale.ENGLISH)) { failed("Invitation invalid. Contact branch Admin."); return@addOnSuccessListener }
            db.collection("Users").document(u.uid).set(mapOf("email" to email, "role" to if (invitedRole == "ADMIN") "ADMIN" else "VIEWER", "branchId" to branchId, "active" to true, "createdAt" to FieldValue.serverTimestamp()))
                .addOnSuccessListener { db.collection("Users").document(u.uid).get().addOnSuccessListener { created -> openMembership(created) } }
                .addOnFailureListener { failed("Invitation join failed: ${it.message ?: "unknown"}") }
        }.addOnFailureListener { failed("Invitation lookup failed: ${it.message ?: "unknown"}") }
    }.addOnFailureListener { failed("Account access read failed: ${it.message ?: "unknown"}") }
}

private fun loadData(db: FirebaseFirestore, setCards: (List<CardRecord>) -> Unit, setEvents: (List<EventRecord>) -> Unit, finished: () -> Unit, toast: (String) -> Unit) {
    if (activeBranchId.isBlank()) { toast("Branch membership missing"); finished(); return }
    var cDone = false; var eDone = false
    fun done() { if (cDone && eDone) finished() }
    db.collection("cards").whereEqualTo("branchId", activeBranchId).get().addOnSuccessListener { snap ->
        setCards(snap.documents.map { d -> CardRecord(d.id, d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("company") ?: "", d.getString("department") ?: "", d.getString("status") ?: "AVAILABLE", d.getString("note") ?: "", d.getTimestamp("reminderDueAt")) })
        cDone = true; done()
    }.addOnFailureListener { cDone = true; toast("Cards read failed: ${it.message ?: "unknown"}"); done() }
    db.collection("card_events").whereEqualTo("branchId", activeBranchId).orderBy("at", Query.Direction.DESCENDING).limit(500).get().addOnSuccessListener { snap ->
        setEvents(snap.documents.map { d -> EventRecord(d.id, d.getString("action") ?: "", d.getString("cardId") ?: "", d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("company") ?: "", d.getString("by") ?: "", d.getTimestamp("at")) })
        eDone = true; done()
    }.addOnFailureListener { eDone = true; toast("History read failed: ${it.message ?: "unknown"}"); done() }
}

private fun emailKey(email: String) = email.trim().lowercase(Locale.ENGLISH).replace("/", "_slash_")
private fun nowBy() = FirebaseAuth.getInstance().currentUser?.email ?: "Unknown user"
private fun fmt(ts: Timestamp?): String = ts?.toDate()?.let { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(it) } ?: "Pending"

@Composable
private fun EmailLoginScreen(busy: Boolean, show: (String) -> Unit, onLogin: (String, String) -> Unit, onRegister: (String, String, String) -> Unit, onForgot: (String) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }; var branchName by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("CSD Card Management", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Text("Independent branch card records", color = Color.Gray)
        Spacer(Modifier.height(24.dp)); Field("Email", email) { email = it }; Field("Password", password) { password = it }; Field("Branch name (for new branch)", branchName) { branchName = it }
        Spacer(Modifier.height(12.dp)); Button({ if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) show("Valid email enter karein") else if (password.length < 6) show("Password minimum 6 characters") else onLogin(email, password) }, Modifier.fillMaxWidth().height(52.dp)) { Text("LOGIN") }
        TextButton({ if (Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) onForgot(email) else show("Email enter karein") }) { Text("Forgot password?") }
        OutlinedButton({ if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) show("Valid email enter karein") else if (password.length < 6) show("Password minimum 6 characters") else if (branchName.isBlank()) show("New branch ke liye branch name zaroori hai") else onRegister(email, password, branchName.trim()) }, Modifier.fillMaxWidth()) { Text("CREATE BRANCH ACCOUNT") }
        if (busy) { Spacer(Modifier.height(12.dp)); CircularProgressIndicator() }
    }
}

@Composable
private fun HomeScreen(
    cards: List<CardRecord>, role: String, add: () -> Unit, issue: () -> Unit, ret: () -> Unit,
    companies: () -> Unit, openCard: (CardRecord) -> Unit, admins: () -> Unit, allCards: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val total = cards.size
    val available = cards.count { it.status == "AVAILABLE" }
    val out = cards.count { it.status == "OUT" }
    val summaries = cards.groupBy { it.company.trim().ifBlank { "Unknown" } }
        .map { (name, list) -> CompanySummary(name, list.size, list.count { it.status == "AVAILABLE" }, list.count { it.status == "OUT" }) }
        .sortedBy { it.name.lowercase(Locale.ENGLISH) }
    val visible = cards.filter {
        q.isBlank() || it.name.contains(q, true) || it.cardNumber.contains(q, true) ||
        it.company.contains(q, true) || it.department.contains(q, true) || it.phone.contains(q, true)
    }.take(8)

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            Column {
                Text("CSD Card Management", fontSize = 25.sp, fontWeight = FontWeight.ExtraBold, color = Purple)
                Text(activeBranchName, fontSize = 13.sp, color = Color.Gray)
                Text(if (role == "ADMIN") "Admin Dashboard" else "Card Management", fontSize = 13.sp, color = Color.Gray)
            }
            Surface(shape = RoundedCornerShape(50), color = Color(0xFFEDE7FF)) {
                Text("● ${role}", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp), fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Purple)
            }
        }
        Spacer(Modifier.height(16.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = Color(0xFFF0EBFF))
        ) {
            Column(Modifier.padding(16.dp)) {
                Text("Card Overview", fontWeight = FontWeight.Bold, fontSize = 18.sp)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    Stat("TOTAL", total, Modifier.weight(1f))
                    Stat("AVAILABLE", available, Modifier.weight(1f))
                    Stat("OUT", out, Modifier.weight(1f))
                }
            }
        }

        Spacer(Modifier.height(14.dp))
        if (role == "ADMIN") {
            Action("＋  ADD CARD", add)
            Action("🔴  ISSUE CARD", issue)
            Action("🔵  RETURN CARD", ret)
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedButton(onClick = companies, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("🏢 Companies") }
            OutlinedButton(onClick = allCards, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Text("▦ All Cards") }
        }
        if (role == "ADMIN") {
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = admins, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Text("👤  Manage Admins") }
        }

        Spacer(Modifier.height(16.dp))
        Text("Quick Search", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Field("Search name, card no., company, department...", q) { q = it }

        if (q.isBlank()) {
            Spacer(Modifier.height(8.dp))
            Text("Company-wise Summary", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            summaries.take(6).forEach { s ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { companies() }, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(s.name, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                            Text("${s.total} cards", fontSize = 12.sp, color = Color.Gray)
                        }
                        Text("Available ${s.available}  •  Out ${s.out}", fontSize = 13.sp)
                        Text("›", fontSize = 24.sp, color = Purple)
                    }
                }
            }
        } else {
            Spacer(Modifier.height(8.dp))
            Text("Search Results", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            visible.forEach { c ->
                Card(Modifier.fillMaxWidth().padding(vertical = 4.dp).clickable { openCard(c) }, shape = RoundedCornerShape(14.dp)) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(c.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold)
                            Text("${c.cardNumber} • ${c.company}", fontSize = 13.sp)
                            Text(c.department.ifBlank { "Department not set" }, fontSize = 12.sp, color = Color.Gray)
                        }
                        StatusBadge(c.status)
                    }
                }
            }
        }
    }
}
@Composable
private fun CompaniesScreen(cards: List<CardRecord>, back: () -> Unit, select: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val summaries = cards
        .groupBy { it.company.trim() }
        .map { (name, list) ->
            CompanySummary(name, list.size, list.count { it.status == "AVAILABLE" }, list.count { it.status == "OUT" })
        }
        .filter { it.name.contains(q, true) }
        .sortedBy { it.name.lowercase() }

    Column(Modifier.fillMaxSize()) {
        ScreenHeader("Companies", back)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Field("Search company...", q) { q = it }
            Spacer(Modifier.height(8.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(summaries) { summary ->
                    Card(Modifier.fillMaxWidth().clickable { select(summary.name) }) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(summary.name, fontWeight = FontWeight.Bold)
                            Text("Total ${summary.total} • Available ${summary.available} • Out ${summary.out}")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CompanyScreen(company: String, cards: List<CardRecord>, back: () -> Unit, open: (CardRecord) -> Unit) {
    Column(Modifier.fillMaxSize()) {
        ScreenHeader(company, back)
        Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Stat("Total", cards.size, Modifier.weight(1f))
                Stat("Available", cards.count { it.status == "AVAILABLE" }, Modifier.weight(1f))
                Stat("Out", cards.count { it.status == "OUT" }, Modifier.weight(1f))
            }
            Spacer(Modifier.height(10.dp))
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(cards) { card ->
                    Card(Modifier.fillMaxWidth().clickable { open(card) }) {
                        Row(
                            Modifier.fillMaxWidth().padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(card.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold)
                                Text(card.cardNumber)
                                Text("${card.department.ifBlank { "Department not set" }} • ${card.phone.ifBlank { "Mobile not set" }}")
                            }
                            StatusBadge(card.status)
                        }
                    }
                }
            }
        }
    }
}

@Composable private fun AllCardsScreen(cards: List<CardRecord>, back: () -> Unit, open: (CardRecord) -> Unit) {
    var q by remember { mutableStateOf("") }; var filter by remember { mutableStateOf("ALL") }
    val list = cards.filter { filter == "ALL" || it.status == filter }.filter { q.isBlank() || listOf(it.name,it.cardNumber,it.company,it.department,it.phone).any { s -> s.contains(q,true) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        ScreenHeader("All Cards", back); Field("Search by name, card no. or company...", q) { q = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)) { FilterChip(filter=="ALL", {filter="ALL"}, label={Text("All (${cards.size})")}); FilterChip(filter=="AVAILABLE", {filter="AVAILABLE"}, label={Text("Available (${cards.count{it.status=="AVAILABLE"}})")}); FilterChip(filter=="OUT", {filter="OUT"}, label={Text("Out (${cards.count{it.status=="OUT"}})")}) }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(list) { c -> Card(Modifier.fillMaxWidth().clickable { open(c) }) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement=Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(c.name.ifBlank{"Name not set"},fontWeight=FontWeight.Bold); Text(c.cardNumber); Text(c.company); Text(c.department.ifBlank{"-"}) }; StatusBadge(c.status) } } } }
    }
}

@Composable private fun SettingsScreen(db: FirebaseFirestore, email: String, role: String, admins: () -> Unit, allCards: () -> Unit, onBranchChange: (String, String, List<String>) -> Unit) {
    var branches by remember { mutableStateOf(listOf<Triple<String, String, List<String>>>()) }
    var menuOpen by remember { mutableStateOf(false) }
    LaunchedEffect(membershipBranchId, role) {
        if (role == "ADMIN" && membershipBranchId.isNotBlank()) {
            db.collection("branches").document(membershipBranchId).get().addOnSuccessListener { root ->
                val rootAncestors = (root.get("ancestorIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                val own = if (root.exists()) listOf(Triple(membershipBranchId, root.getString("name") ?: "My Branch", rootAncestors)) else emptyList()
                db.collection("branches").whereArrayContains("ancestorIds", membershipBranchId).get().addOnSuccessListener { snap ->
                    val children = snap.documents.map { d -> Triple(d.id, d.getString("name") ?: "Branch", (d.get("ancestorIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList()) }
                    branches = (own + children).distinctBy { it.first }.sortedBy { it.second.lowercase(Locale.ENGLISH) }
                }.addOnFailureListener { branches = own }
            }
        }
    }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
        Text("Settings", style=MaterialTheme.typography.headlineSmall, fontWeight=FontWeight.Bold)
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement=Arrangement.spacedBy(5.dp)) { Text("Account",fontWeight=FontWeight.Bold); Text(email); Text("Role: $role") } }
        if (role == "ADMIN") {
            Text("Active branch", fontWeight=FontWeight.Bold)
            Box {
                OutlinedButton(onClick = { menuOpen = true }, modifier = Modifier.fillMaxWidth()) { Text("$activeBranchName  ▾") }
                DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                    branches.forEach { (id, name, ancestors) ->
                        DropdownMenuItem(text = { Text(name) }, onClick = { menuOpen = false; onBranchChange(id, name, ancestors) })
                    }
                }
            }
            Text("Switching branch changes which branch's cards you manage. Access is limited to your branch and its sub-branches.", fontSize=12.sp, color=Color.Gray)
        }
        OutlinedButton(allCards, Modifier.fillMaxWidth()) { Text("ALL CARDS") }
        if (role == "ADMIN") OutlinedButton(admins, Modifier.fillMaxWidth()) { Text("MANAGE USERS / SUB-BRANCHES") }
        Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) { Text("CSD Card Management",fontWeight=FontWeight.Bold); Text("Branch-scoped card management") } }
    }
}

@Composable private fun CardDetailsScreen(card: CardRecord?, history: List<EventRecord>, back: () -> Unit, admin: Boolean, db: FirebaseFirestore, done: (String) -> Unit, edit: () -> Unit) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    ScreenHeader("Card Details", back)
    if (card == null) { Text("Card not found", Modifier.padding(16.dp)); return }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(card.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    StatusBadge(card.status)
                }
                Text("Card Number: ${card.cardNumber}")
                Text("Company: ${card.company}")
                Text("Department: ${card.department.ifBlank { "-" }}")
                Text("Mobile: ${card.phone.ifBlank { "-" }}")
                Text("Remarks: ${card.note.ifBlank { "-" }}")
                if (card.status == "OUT" && card.reminderDueAt != null) Text("Reminder due: ${fmt(card.reminderDueAt)}", color = Purple, fontWeight = FontWeight.SemiBold)
                if (card.phone.isNotBlank()) {
                    val context = LocalContext.current
                    OutlinedButton(onClick = {
                        val body = if (card.status == "OUT") "CSD Card Management: Card ${card.cardNumber} has been issued to ${card.name}. Please return the card as scheduled." else "CSD Card Management: Card ${card.cardNumber} has been returned successfully."
                        val intent = Intent(Intent.ACTION_SENDTO).apply { data = Uri.parse("smsto:${card.phone}"); putExtra("sms_body", body) }
                        context.startActivity(intent)
                    }, modifier=Modifier.fillMaxWidth()) { Text("📱 SEND SMS") }
                }
            }
        }
        Spacer(Modifier.height(12.dp))
        if (admin) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button({
                    if (card.status == "AVAILABLE") {
                        val ref = db.collection("cards").document(card.id)
                        ref.update("status", "OUT", "outAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp())
                            .addOnSuccessListener {
                                db.collection("card_events").add(mapOf("cardId" to card.id, "cardNumber" to card.cardNumber, "name" to card.name, "company" to card.company, "branchId" to activeBranchId, "action" to "ISSUE", "by" to nowBy(), "at" to FieldValue.serverTimestamp()))
                                    .addOnSuccessListener { done("Card issued"); back() }
                                    .addOnFailureListener { done("Card issued, but history save failed: ${it.message ?: "unknown"}") }
                            }
                            .addOnFailureListener { done(it.message ?: "Issue failed") }
                    } else done("Card already OUT")
                }, Modifier.weight(1f)) { Text("ISSUE CARD") }
                Button({
                    if (card.status == "OUT") {
                        val ref = db.collection("cards").document(card.id)
                        ref.update("status", "AVAILABLE", "depositAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp(), "reminderDueAt", null)
                            .addOnSuccessListener {
                                db.collection("card_events").add(mapOf("cardId" to card.id, "cardNumber" to card.cardNumber, "name" to card.name, "company" to card.company, "branchId" to activeBranchId, "action" to "RETURN", "by" to nowBy(), "at" to FieldValue.serverTimestamp()))
                                    .addOnSuccessListener { done("Card returned"); back() }
                                    .addOnFailureListener { done("Card returned, but history save failed: ${it.message ?: "unknown"}") }
                            }
                            .addOnFailureListener { done(it.message ?: "Return failed") }
                    } else done("Card already AVAILABLE")
                }, Modifier.weight(1f)) { Text("RETURN CARD") }
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(
                onClick = edit,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                shape = RoundedCornerShape(14.dp)
            ) { Text("✏️  EDIT CARD") }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (!deleting) showDeleteConfirm = true },
                enabled = !deleting,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))
            ) { Text(if (deleting) "DELETING..." else "🗑  DELETE CARD PERMANENTLY") }
            Text("Only Admin can permanently delete a card. Its history is kept for audit.", fontSize = 12.sp, color = Color.Gray)
        }
        Spacer(Modifier.height(16.dp)); Text("History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(history) { e -> Row(Modifier.fillMaxWidth(), verticalAlignment=Alignment.Top) { Surface(shape=RoundedCornerShape(50),color=when(e.action){"ISSUE"->Color(0xFFFFD9DE);"RETURN"->Color(0xFFD8F5DF);else->Color(0xFFDDE8FF)},modifier=Modifier.size(14.dp)){ } ; Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f).padding(bottom=8.dp)) { Text(when(e.action){"ADD"->"Card Added";"ISSUE"->"Card Issued";"RETURN"->"Card Returned";"EDIT"->"Card Edited";"DELETE"->"Card Deleted";else->e.action},fontWeight=FontWeight.Bold); Text(fmt(e.at)); Text("${when(e.action){"ISSUE"->"Issued";"RETURN"->"Returned";"EDIT"->"Edited";"DELETE"->"Deleted";else->"Added"}} by: ${e.by.ifBlank{"Unknown"}}") } } }
        }
    }
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { if (!deleting) showDeleteConfirm = false },
            title = { Text("Delete card permanently?") },
            text = { Text("Card ${card.cardNumber} will be removed from the active cards permanently. Its history will remain for audit. This cannot be undone.") },
            confirmButton = {
                TextButton(enabled = !deleting, onClick = {
                    deleting = true
                    val ref = db.collection("cards").document(card.id)
                    db.runTransaction { tx ->
                        val snap = tx.get(ref)
                        if (!snap.exists()) throw IllegalStateException("Card already deleted")
                        tx.set(db.collection("card_events").document(), mapOf(
                            "cardId" to card.id,
                            "cardNumber" to card.cardNumber,
                            "name" to card.name,
                            "company" to card.company,
                            "branchId" to activeBranchId, "action" to "DELETE",
                            "by" to nowBy(),
                            "at" to FieldValue.serverTimestamp()
                        ))
                        tx.delete(ref)
                    }.addOnSuccessListener {
                        deleting = false
                        showDeleteConfirm = false
                        done("Card permanently deleted")
                        back()
                    }.addOnFailureListener {
                        deleting = false
                        done(it.message ?: "Delete failed")
                    }
                }) { Text("DELETE", color = Color(0xFFB3261E), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(enabled = !deleting, onClick = { showDeleteConfirm = false }) { Text("CANCEL") } }
        )
    }
}

@Composable private fun AddCardScreen(db: FirebaseFirestore, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var number by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }; var dept by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }
    Form("ADD CARD", back) {
        if (!admin) { Text("Viewer cannot add cards."); return@Form }
        Field("Person Name *", name) { name=it }; Field("Card Number *", number) { number=it }; Field("Company *", company) { company=it }; Field("Department", dept) { dept=it }; Field("Mobile Number", phone) { phone=it }; Field("Remarks", note) { note=it }
        Button({
            if (saving) return@Button
            if (number.isBlank()||company.isBlank()||name.isBlank()) { done("Name, card number and company required"); return@Button }
            saving = true
            val cardNo = number.trim(); val person = name.trim(); val comp = company.trim()
            db.collection("cards").whereEqualTo("branchId", activeBranchId).whereEqualTo("cardNumber",cardNo).limit(1).get().addOnSuccessListener {
                if (!it.isEmpty) { saving=false; done("Card number already exists") }
                else {
                    val ref=db.collection("cards").document()
                    ref.set(mapOf("branchId" to activeBranchId,"name" to person,"phone" to phone.trim(),"cardNumber" to cardNo,"company" to comp,"department" to dept.trim(),"status" to "AVAILABLE","note" to note.trim(),"createdAt" to FieldValue.serverTimestamp(),"updatedAt" to FieldValue.serverTimestamp()))
                        .addOnSuccessListener {
                            db.collection("card_events").add(mapOf("cardId" to ref.id,"cardNumber" to cardNo,"name" to person,"company" to comp,"branchId" to activeBranchId, "action" to "ADD","by" to nowBy(),"at" to FieldValue.serverTimestamp()))
                                .addOnSuccessListener { saving=false; done("Card added successfully"); back() }
                                .addOnFailureListener { saving=false; done("Card saved, but history save failed: ${it.message ?: "unknown"}") }
                        }
                        .addOnFailureListener { saving=false; done(it.message ?: "Card save failed") }
                }
            }.addOnFailureListener { saving=false; done(it.message ?: "Duplicate check failed") }
        }, enabled=!saving, modifier=Modifier.fillMaxWidth().height(52.dp)) { Text(if (saving) "SAVING..." else "ADD CARD") }
    }
}

@Composable
private fun EditCardScreen(
    db: FirebaseFirestore, card: CardRecord?, admin: Boolean,
    done: (String) -> Unit, back: () -> Unit
) {
    if (card == null) { Form("EDIT CARD", back) { Text("Card not found") }; return }
    var name by remember { mutableStateOf(card.name) }
    var phone by remember { mutableStateOf(card.phone) }
    var number by remember { mutableStateOf(card.cardNumber) }
    var company by remember { mutableStateOf(card.company) }
    var dept by remember { mutableStateOf(card.department) }
    var note by remember { mutableStateOf(card.note) }
    var saving by remember { mutableStateOf(false) }

    Form("EDIT CARD", back) {
        if (!admin) { Text("Only Admin can edit cards."); return@Form }
        Field("Person Name *", name) { name = it }
        Field("Card Number *", number) { number = it }
        Field("Company *", company) { company = it }
        Field("Department", dept) { dept = it }
        Field("Mobile Number", phone) { phone = it }
        Field("Remarks", note) { note = it }
        Button(
            onClick = {
                if (saving) return@Button
                if (name.isBlank() || number.isBlank() || company.isBlank()) {
                    done("Name, card number and company required"); return@Button
                }
                saving = true
                val newNo = number.trim()
                val finishUpdate = {
                    val ref = db.collection("cards").document(card.id)
                    ref.update(
                        mapOf(
                            "name" to name.trim(), "phone" to phone.trim(), "cardNumber" to newNo,
                            "company" to company.trim(), "department" to dept.trim(),
                            "note" to note.trim(), "updatedAt" to FieldValue.serverTimestamp()
                        )
                    ).addOnSuccessListener {
                        db.collection("card_events").add(
                            mapOf(
                                "cardId" to card.id, "cardNumber" to newNo, "name" to name.trim(),
                                "company" to company.trim(), "branchId" to activeBranchId, "action" to "EDIT",
                                "by" to nowBy(), "at" to FieldValue.serverTimestamp()
                            )
                        ).addOnSuccessListener {
                            saving = false; done("Card updated successfully"); back()
                        }.addOnFailureListener {
                            saving = false; done("Card updated, but history save failed")
                            back()
                        }
                    }.addOnFailureListener { saving = false; done(it.message ?: "Update failed") }
                }
                if (newNo.equals(card.cardNumber, true)) {
                    finishUpdate()
                } else {
                    db.collection("cards").whereEqualTo("branchId", activeBranchId).whereEqualTo("cardNumber", newNo).limit(1).get()
                        .addOnSuccessListener {
                            if (!it.isEmpty) { saving = false; done("Card number already exists") }
                            else finishUpdate()
                        }.addOnFailureListener { saving = false; done(it.message ?: "Duplicate check failed") }
                }
            },
            enabled = !saving, modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text(if (saving) "SAVING..." else "SAVE CHANGES") }
    }
}

@Composable
private fun IssueScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    val context = LocalContext.current
    var number by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var reminderMode by remember { mutableStateOf("24") }
    var customDays by remember { mutableStateOf("") }
    val selected = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }

    LaunchedEffect(selected?.id) {
        if (selected != null) { name = selected.name; phone = selected.phone }
    }

    Form("ISSUE CARD", back) {
        if (!admin) { Text("Viewer cannot issue cards."); return@Form }
        Field("Card Number *", number) { number = it }
        if (selected != null) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0EBFF))) {
                Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(selected.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                    Text("${selected.cardNumber} • ${selected.company}")
                    Text("${selected.department.ifBlank { "-" }} • ${selected.phone.ifBlank { "-" }}")
                    StatusBadge(selected.status)
                }
            }
        }
        Field("Issue To (Person Name) *", name) { name = it }
        Field("Mobile Number", phone) { phone = it }
        Text("Reminder after", fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("24", "48", "72", "CUSTOM").forEach { option ->
                FilterChip(reminderMode == option, { reminderMode = option }, label = {
                    Text(if (option == "CUSTOM") "Custom" else "${option}h")
                })
            }
        }
        if (reminderMode == "CUSTOM") {
            Field("Custom reminder days (e.g. 30, 60)", customDays) {
                customDays = it.filter { ch -> ch.isDigit() }.take(4)
            }
            Text("Example: 30 days or 60 days after issue.", fontSize = 12.sp, color = Color.Gray)
        }

        Button({
            val c = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }
            if (c == null) {
                done("Card not found")
            } else if (c.status == "OUT") {
                done("Card already OUT")
            } else {
                val days: Long? = if (reminderMode == "CUSTOM") customDays.toLongOrNull() else null
                if (reminderMode == "CUSTOM" && (days == null || days < 1L || days > 3650L)) {
                    done("Enter custom days between 1 and 3650")
                } else {
                    val hours = if (reminderMode == "CUSTOM") days!! * 24L else reminderMode.toLong()
                    val due = Timestamp(Date(System.currentTimeMillis() + hours * 3600000L))
                    val ref = db.collection("cards").document(c.id)
                    db.runTransaction { tx ->
                        val s = tx.get(ref)
                        if (s.getString("status") != "AVAILABLE") throw IllegalStateException("Card is not available")
                        tx.update(ref, mapOf(
                            "status" to "OUT",
                            "name" to name.trim(),
                            "phone" to phone.trim(),
                            "outAt" to FieldValue.serverTimestamp(),
                            "reminderDueAt" to due,
                            "reminderHours" to hours,
                            "updatedAt" to FieldValue.serverTimestamp()
                        ))
                        tx.set(db.collection("card_events").document(), mapOf(
                            "cardId" to c.id, "cardNumber" to c.cardNumber, "name" to name.trim(),
                            "company" to c.company, "branchId" to activeBranchId, "action" to "ISSUE", "by" to nowBy(),
                            "at" to FieldValue.serverTimestamp(), "reminderHours" to hours
                        ))
                    }.addOnSuccessListener {
                        scheduleCardReminder(context, c.id, c.cardNumber, name.trim(), due)
                        done("Card issued; reminder scheduled"); back()
                    }
                        .addOnFailureListener { done(it.message ?: "Issue failed") }
                }
            }
        }, Modifier.fillMaxWidth().height(52.dp)) { Text("ISSUE / CARD OUT") }
    }
}

@Composable
private fun ReturnScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    val context = LocalContext.current
    var number by remember { mutableStateOf("") }
    val selected = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }

    Form("RETURN CARD", back) {
        if (!admin) {
            Text("Viewer cannot return cards.")
            return@Form
        }
        Field("Card Number *", number) { number = it }
        if (selected != null) {
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Text(selected.name, fontWeight = FontWeight.Bold)
                    Text("${selected.cardNumber} • ${selected.company}")
                    Text("${selected.department} • ${selected.phone}")
                    StatusBadge(selected.status)
                }
            }
        }
        Button(
            onClick = {
                val card = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }
                when {
                    card == null -> done("Card not found")
                    card.status != "OUT" -> done("Card is already AVAILABLE")
                    else -> {
                        val ref = db.collection("cards").document(card.id)
                        db.runTransaction { tx ->
                            val snap = tx.get(ref)
                            if (snap.getString("status") != "OUT") throw IllegalStateException("Card is not OUT")
                            tx.update(ref, mapOf(
                                "status" to "AVAILABLE",
                                "depositAt" to FieldValue.serverTimestamp(),
                                "updatedAt" to FieldValue.serverTimestamp(),
                                "reminderDueAt" to null
                            ))
                            tx.set(db.collection("card_events").document(), mapOf(
                                "cardId" to card.id,
                                "cardNumber" to card.cardNumber,
                                "name" to (snap.getString("name") ?: card.name),
                                "company" to card.company,
                                "branchId" to activeBranchId, "action" to "RETURN",
                                "by" to nowBy(),
                                "at" to FieldValue.serverTimestamp()
                            ))
                        }.addOnSuccessListener {
                            cancelCardReminder(context, card.id)
                            done("Card returned; reminder stopped")
                            back()
                        }.addOnFailureListener {
                            done(it.message ?: "Return failed")
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(52.dp)
        ) { Text("RETURN / DEPOSIT") }
    }
}

@Composable
private fun HistoryScreen(events: List<EventRecord>, open: (EventRecord) -> Unit) {
    var q by remember { mutableStateOf("") }
    val list = events.filter {
        q.isBlank() || listOf(it.name, it.cardNumber, it.company, it.action).any { value -> value.contains(q, true) }
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("History", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Field("Search name, card no. or company", q) { q = it }
        Spacer(Modifier.height(8.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(list) { event ->
                Card(Modifier.fillMaxWidth().clickable { open(event) }) {
                    Column(Modifier.padding(12.dp)) {
                        Text("${event.name.ifBlank { "Unknown" }} • ${event.cardNumber}", fontWeight = FontWeight.Bold)
                        Text("${event.action} • ${event.company}")
                        Text(fmt(event.at))
                        Text("By: ${event.by.ifBlank { "Unknown" }}")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportsScreen(cards: List<CardRecord>) {
    val context = LocalContext.current
    var company by remember { mutableStateOf("All Companies") }
    val companies = listOf("All Companies") + cards.map { it.company }.filter { it.isNotBlank() }.distinct().sorted()
    val filtered = cards.filter { company == "All Companies" || it.company.equals(company, true) }
    val csv = buildString {
        appendLine("Name,Card Number,Company,Department,Phone,Status,Remarks")
        filtered.forEach { card ->
            appendLine(listOf(card.name, card.cardNumber, card.company, card.department, card.phone, card.status, card.note)
                .joinToString(",") { value -> "\"${value.replace("\"", "\"\"")}\"" })
        }
    }
    var expanded by remember { mutableStateOf(false) }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Reports", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        Box {
            OutlinedButton({ expanded = true }, Modifier.fillMaxWidth()) { Text(company) }
            DropdownMenu(expanded, { expanded = false }) {
                companies.forEach { item ->
                    DropdownMenuItem(text = { Text(item) }, onClick = { company = item; expanded = false })
                }
            }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Stat("Total", filtered.size, Modifier.weight(1f))
            Stat("Available", filtered.count { it.status == "AVAILABLE" }, Modifier.weight(1f))
            Stat("Out", filtered.count { it.status == "OUT" }, Modifier.weight(1f))
        }
        Spacer(Modifier.height(12.dp))
        Button(
            onClick = {
                val intent = Intent(Intent.ACTION_SEND).apply {
                    type = "text/csv"
                    putExtra(Intent.EXTRA_SUBJECT, "CSD Card Management Report")
                    putExtra(Intent.EXTRA_TEXT, csv)
                }
                context.startActivity(Intent.createChooser(intent, "Export CSV"))
            },
            modifier = Modifier.fillMaxWidth()
        ) { Text("EXPORT CSV") }
        Spacer(Modifier.height(12.dp))
        Text("Company-wise Summary", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(
                filtered.groupBy { it.company }
                    .map { (name, list) -> CompanySummary(name, list.size, list.count { it.status == "AVAILABLE" }, list.count { it.status == "OUT" }) }
                    .sortedBy { it.name }
            ) { summary ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(summary.name, fontWeight = FontWeight.Bold)
                        Text("Total ${summary.total} • Available ${summary.available} • Out ${summary.out}")
                    }
                }
            }
        }
    }
}

@Composable
private fun AdminManagementScreen(
    db: FirebaseFirestore,
    admin: Boolean,
    done: (String) -> Unit,
    back: () -> Unit
) {
    var email by remember { mutableStateOf("") }
    var newBranchName by remember { mutableStateOf("") }
    var users by remember { mutableStateOf(listOf<ManagedUser>()) }
    var children by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var targetBranchId by remember { mutableStateOf(activeBranchId) }

    fun load() {
        db.collection("email_roles").whereEqualTo("branchId", targetBranchId).get().addOnSuccessListener { snap ->
            users = snap.documents.map { ManagedUser(it.getString("email") ?: it.id, it.getString("role") ?: "VIEWER") }.sortedBy { it.email }
        }
        db.collection("branches").whereEqualTo("parentBranchId", activeBranchId).get().addOnSuccessListener { snap ->
            children = snap.documents.map { it.id to (it.getString("name") ?: "Sub-branch") }.sortedBy { it.second.lowercase(Locale.ENGLISH) }
        }
    }

    LaunchedEffect(admin, activeBranchId, targetBranchId) { if (admin) load() }

    Form("MANAGE USERS & SUB-BRANCHES", back) {
        if (!admin) { Text("Only Admin can manage users."); return@Form }
        Text("Current branch: $activeBranchName", fontWeight = FontWeight.Bold)
        if (children.isNotEmpty()) {
            Text("Direct sub-branches", fontWeight = FontWeight.SemiBold)
            children.forEach { (id, name) ->
                OutlinedButton(onClick = { targetBranchId = id }, modifier = Modifier.fillMaxWidth()) { Text((if (targetBranchId == id) "✓ " else "") + name) }
            }
        }
        Field("New sub-branch name", newBranchName) { newBranchName = it }
        Button(onClick = {
            val name = newBranchName.trim()
            if (name.length < 2) { done("Sub-branch name at least 2 characters"); return@Button }
            val ref = db.collection("branches").document()
            val ancestors = activeBranchAncestors + activeBranchId
            val data = mapOf("name" to name, "ownerUid" to (FirebaseAuth.getInstance().currentUser?.uid ?: ""), "createdBy" to (FirebaseAuth.getInstance().currentUser?.uid ?: ""), "parentBranchId" to activeBranchId, "ancestorIds" to ancestors, "active" to true, "createdAt" to FieldValue.serverTimestamp())
            ref.set(data).addOnSuccessListener {
                newBranchName = ""; children = children + (ref.id to name); targetBranchId = ref.id
                activeBranchId = ref.id; activeBranchName = name; activeBranchAncestors = ancestors
                done("Sub-branch created. Invite its Admin below."); load()
            }.addOnFailureListener { done("Sub-branch creation failed: ${it.message ?: "unknown"}") }
        }, modifier = Modifier.fillMaxWidth()) { Text("CREATE SUB-BRANCH") }

        Spacer(Modifier.height(8.dp))
        Text("Invite role for: ${if (targetBranchId == activeBranchId) activeBranchName else children.firstOrNull { it.first == targetBranchId }?.second ?: "Selected branch"}", fontWeight = FontWeight.Bold)
        Field("Email Address", email) { email = it }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            Button(onClick = {
                val value = email.trim().lowercase(Locale.ENGLISH)
                if (!Patterns.EMAIL_ADDRESS.matcher(value).matches()) done("Valid email required")
                else db.collection("email_roles").document(emailKey(value)).set(mapOf("email" to value, "role" to "ADMIN", "branchId" to targetBranchId, "updatedAt" to FieldValue.serverTimestamp()))
                    .addOnSuccessListener { done("Admin invitation saved"); email = ""; load() }
                    .addOnFailureListener { done(it.message ?: "Admin assignment failed") }
            }, modifier = Modifier.weight(1f)) { Text("INVITE ADMIN") }
            OutlinedButton(onClick = {
                val value = email.trim().lowercase(Locale.ENGLISH)
                if (!Patterns.EMAIL_ADDRESS.matcher(value).matches()) done("Valid email required")
                else db.collection("email_roles").document(emailKey(value)).set(mapOf("email" to value, "role" to "VIEWER", "branchId" to targetBranchId, "updatedAt" to FieldValue.serverTimestamp()))
                    .addOnSuccessListener { done("Viewer invitation saved"); email = ""; load() }
                    .addOnFailureListener { done(it.message ?: "Viewer assignment failed") }
            }, modifier = Modifier.weight(1f)) { Text("INVITE VIEWER") }
        }
        Spacer(Modifier.height(12.dp))
        users.forEach { managed -> Card(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) { Text(managed.email); Text(managed.role, fontWeight = FontWeight.Bold) }
                TextButton(onClick = {
                    db.collection("email_roles").document(emailKey(managed.email)).delete()
                        .addOnSuccessListener { done("Invitation revoked"); load() }
                        .addOnFailureListener { done(it.message ?: "Could not revoke invitation") }
                }) { Text("REVOKE") }
            }
        } }
    }
}

