# GUTRIAN CSD — FINAL SOURCE
Native Android Firebase app source.

Project: card-flow-manger
Package: com.gutrian.csd
Admin: gutrian-csd@gmail.com

Included: email/password login, admin/viewer role handling, add/issue/return, search, company-wise counts, Firestore history, performer recorded in events, offline-capable Firestore client, and secure Firestore rules.

Important limitation: arbitrary SMS to card-holder phone numbers requires an SMS gateway/provider. Firebase Auth SMS is not an arbitrary notification service. The app records the phone/message event; do not advertise free arbitrary SMS as already enabled.
