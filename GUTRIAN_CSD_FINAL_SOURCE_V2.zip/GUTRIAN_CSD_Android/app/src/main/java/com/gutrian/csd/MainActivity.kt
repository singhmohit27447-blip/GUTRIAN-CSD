@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package com.gutrian.csd

import android.os.Bundle
import android.util.Patterns
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.FirebaseApp
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.SetOptions
import java.text.SimpleDateFormat
import java.util.*

private const val ADMIN_EMAIL = "gutrian-csd@gmail.com"
private val Purple = Color(0xFF5E4AA8)
private val LightBg = Color(0xFFFFF8FF)

data class CardRecord(
    val id: String = "", val cardNumber: String = "", val name: String = "",
    val phone: String = "", val company: String = "", val department: String = "",
    val status: String = "AVAILABLE", val note: String = "", val reminderDueAt: Timestamp? = null
)
data class EventRecord(
    val id: String = "", val action: String = "", val cardId: String = "", val cardNumber: String = "",
    val name: String = "", val company: String = "", val by: String = "", val at: Timestamp? = null
)
data class ManagedUser(val email: String, val role: String)
data class CompanySummary(val name: String, val total: Int, val available: Int, val out: Int)

enum class AppScreen { HOME, COMPANIES, COMPANY, CARD, ADD, ISSUE, RETURN, HISTORY, REPORTS, ADMINS }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = lightColorScheme(primary = Purple, background = LightBg)) { GutrianCsdApp() } }
    }
}

@Composable
fun GutrianCsdApp() {
    val auth = remember { FirebaseAuth.getInstance(FirebaseApp.getInstance()) }
    val db = remember { FirebaseFirestore.getInstance(FirebaseApp.getInstance()) }
    val context = LocalContext.current
    var user by remember { mutableStateOf(auth.currentUser) }
    var role by remember { mutableStateOf("VIEWER") }
    var cards by remember { mutableStateOf(listOf<CardRecord>()) }
    var events by remember { mutableStateOf(listOf<EventRecord>()) }
    var screen by remember { mutableStateOf(AppScreen.HOME) }
    var selectedCompany by remember { mutableStateOf("") }
    var selectedCard by remember { mutableStateOf<CardRecord?>(null) }
    var busy by remember { mutableStateOf(false) }
    var toast by remember { mutableStateOf("") }

    fun show(s: String) { toast = s }
    fun reload() {
        val u = auth.currentUser ?: return
        busy = true
        val email = (u.email ?: "").trim().lowercase(Locale.ENGLISH)
        u.getIdToken(true).addOnSuccessListener {
            resolveRole(db, u, email,
                { role = it },
                { loadData(db, { cards = it }, { events = it }, { busy = false }, show) },
                { busy = false; show(it) })
        }.addOnFailureListener { busy = false; show(it.message ?: "Login token failed") }
    }

    DisposableEffect(Unit) {
        val listener = FirebaseAuth.AuthStateListener { user = it.currentUser }
        auth.addAuthStateListener(listener)
        onDispose { auth.removeAuthStateListener(listener) }
    }
    LaunchedEffect(user?.uid) { if (user != null) reload() }

    if (user == null) {
        EmailLoginScreen(busy, show,
            { email, password ->
                busy = true
                auth.signInWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { user = it.user; busy = false }
                    .addOnFailureListener { busy = false; show(it.message ?: "Login failed") }
            },
            { email, password ->
                busy = true
                auth.createUserWithEmailAndPassword(email.trim(), password)
                    .addOnSuccessListener { user = it.user; busy = false; show("Account created") }
                    .addOnFailureListener { busy = false; show(it.message ?: "Account create failed") }
            },
            { email ->
                busy = true
                auth.sendPasswordResetEmail(email.trim())
                    .addOnSuccessListener { busy = false; show("Password reset email sent") }
                    .addOnFailureListener { busy = false; show(it.message ?: "Reset failed") }
            })
    } else {
        Scaffold(
            topBar = {
                TopAppBar(title = { Text("GUTRIAN CSD", fontWeight = FontWeight.Bold) }, actions = {
                    TextButton(onClick = { auth.signOut(); user = null }) { Text("Logout") }
                })
            },
            bottomBar = {
                if (screen !in listOf(AppScreen.ADD, AppScreen.ISSUE, AppScreen.RETURN, AppScreen.COMPANY, AppScreen.CARD, AppScreen.COMPANIES, AppScreen.ADMINS)) {
                    NavigationBar {
                        NavigationBarItem(screen == AppScreen.HOME, { screen = AppScreen.HOME }, icon = { Text("⌂") }, label = { Text("Home") })
                        NavigationBarItem(screen == AppScreen.HISTORY, { screen = AppScreen.HISTORY }, icon = { Text("◷") }, label = { Text("History") })
                        NavigationBarItem(screen == AppScreen.REPORTS, { screen = AppScreen.REPORTS }, icon = { Text("▥") }, label = { Text("Reports") })
                    }
                }
            }
        ) { pad ->
            Box(Modifier.fillMaxSize().padding(pad)) {
                when (screen) {
                    AppScreen.HOME -> HomeScreen(cards, role, { screen = AppScreen.ADD }, { screen = AppScreen.ISSUE }, { screen = AppScreen.RETURN }, { screen = AppScreen.COMPANIES }, { q -> selectedCard = q; screen = AppScreen.CARD }, { screen = AppScreen.ADMINS })
                    AppScreen.COMPANIES -> CompaniesScreen(cards, { screen = AppScreen.HOME }, { selectedCompany = it; screen = AppScreen.COMPANY })
                    AppScreen.COMPANY -> CompanyScreen(selectedCompany, cards.filter { it.company.equals(selectedCompany, true) }, { screen = AppScreen.COMPANIES }, { selectedCard = it; screen = AppScreen.CARD })
                    AppScreen.CARD -> CardDetailsScreen(selectedCard, events.filter { it.cardId == selectedCard?.id }, { screen = AppScreen.HOME }, role == "ADMIN", db, { show(it); reload() })
                    AppScreen.ADD -> AddCardScreen(db, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.ISSUE -> IssueScreen(db, cards, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.RETURN -> ReturnScreen(db, cards, role == "ADMIN", { show(it); reload(); screen = AppScreen.HOME }, { screen = AppScreen.HOME })
                    AppScreen.HISTORY -> HistoryScreen(events) { ev -> selectedCard = cards.firstOrNull { it.id == ev.cardId }; screen = AppScreen.CARD }
                    AppScreen.REPORTS -> ReportsScreen(cards)
                    AppScreen.ADMINS -> AdminManagementScreen(db, role == "ADMIN", { show(it) }, { screen = AppScreen.HOME })
                }
            }
        }
    }

    if (busy) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    if (toast.isNotBlank()) {
        LaunchedEffect(toast) { Toast.makeText(context, toast, Toast.LENGTH_LONG).show(); toast = "" }
    }
}

private fun resolveRole(db: FirebaseFirestore, u: FirebaseUser, email: String, setRole: (String) -> Unit, loaded: () -> Unit, failed: (String) -> Unit) {
    if (email == ADMIN_EMAIL) {
        setRole("ADMIN")
        db.collection("Users").document(u.uid).set(mapOf("email" to email, "role" to "ADMIN", "Role" to "ADMIN", "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { loaded() }
        return
    }
    db.collection("Users").document(u.uid).get().addOnSuccessListener { d ->
        val direct = (d.getString("role") ?: d.getString("Role") ?: "").uppercase(Locale.ENGLISH)
        if (direct == "ADMIN" || direct == "VIEWER") { setRole(direct); loaded() }
        else db.collection("email_roles").document(emailKey(email)).get().addOnSuccessListener { er ->
            val r = (er.getString("role") ?: "VIEWER").uppercase(Locale.ENGLISH)
            setRole(if (r == "ADMIN") "ADMIN" else "VIEWER")
            db.collection("Users").document(u.uid).set(mapOf("email" to email, "role" to r, "updatedAt" to FieldValue.serverTimestamp()), SetOptions.merge()).addOnCompleteListener { loaded() }
        }.addOnFailureListener { setRole("VIEWER"); loaded() }
    }.addOnFailureListener { failed("Role read failed: ${it.message ?: "unknown"}") }
}

private fun loadData(db: FirebaseFirestore, setCards: (List<CardRecord>) -> Unit, setEvents: (List<EventRecord>) -> Unit, finished: () -> Unit, toast: (String) -> Unit) {
    var cDone = false; var eDone = false
    fun done() { if (cDone && eDone) finished() }
    db.collection("cards").get().addOnSuccessListener { snap ->
        setCards(snap.documents.map { d -> CardRecord(d.id, d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("phone") ?: "", d.getString("company") ?: "", d.getString("department") ?: "", d.getString("status") ?: "AVAILABLE", d.getString("note") ?: "", d.getTimestamp("reminderDueAt")) })
        cDone = true; done()
    }.addOnFailureListener { cDone = true; toast("Cards read failed: ${it.message ?: "unknown"}"); done() }
    db.collection("card_events").orderBy("at", Query.Direction.DESCENDING).limit(500).get().addOnSuccessListener { snap ->
        setEvents(snap.documents.map { d -> EventRecord(d.id, d.getString("action") ?: "", d.getString("cardId") ?: "", d.getString("cardNumber") ?: "", d.getString("name") ?: "", d.getString("company") ?: "", d.getString("by") ?: "", d.getTimestamp("at")) })
        eDone = true; done()
    }.addOnFailureListener { eDone = true; toast("History read failed: ${it.message ?: "unknown"}"); done() }
}

private fun emailKey(email: String) = email.trim().lowercase(Locale.ENGLISH).replace("/", "_slash_")
private fun nowBy() = FirebaseAuth.getInstance().currentUser?.email ?: ADMIN_EMAIL
private fun fmt(ts: Timestamp?): String = ts?.toDate()?.let { SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH).format(it) } ?: "Pending"

@Composable
private fun EmailLoginScreen(busy: Boolean, show: (String) -> Unit, onLogin: (String, String) -> Unit, onRegister: (String, String) -> Unit, onForgot: (String) -> Unit) {
    var email by remember { mutableStateOf("") }; var password by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
        Text("GUTRIAN CSD", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(24.dp)); Field("Email", email) { email = it }; Field("Password", password) { password = it }
        Spacer(Modifier.height(12.dp)); Button({ if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) show("Valid email enter karein") else if (password.length < 6) show("Password minimum 6 characters") else onLogin(email, password) }, Modifier.fillMaxWidth().height(52.dp)) { Text("LOGIN") }
        TextButton({ if (Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) onForgot(email) else show("Email enter karein") }) { Text("Forgot password?") }
        OutlinedButton({ if (!Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) show("Valid email enter karein") else if (password.length < 6) show("Password minimum 6 characters") else onRegister(email, password) }, Modifier.fillMaxWidth()) { Text("CREATE ACCOUNT") }
        if (busy) { Spacer(Modifier.height(12.dp)); CircularProgressIndicator() }
    }
}

@Composable
private fun HomeScreen(cards: List<CardRecord>, role: String, add: () -> Unit, issue: () -> Unit, ret: () -> Unit, companies: () -> Unit, openCard: (CardRecord) -> Unit, admins: () -> Unit) {
    var q by remember { mutableStateOf("") }
    val total = cards.size; val available = cards.count { it.status == "AVAILABLE" }; val out = cards.count { it.status == "OUT" }
    val visible = cards.filter { q.isBlank() || listOf(it.name,it.cardNumber,it.company,it.department,it.phone).any { s -> s.contains(q, true) } }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { Stat("Total", total); Stat("Available", available); Stat("Out", out) }
        Spacer(Modifier.height(12.dp)); if (role == "ADMIN") { Action("➕  ADD CARD", add); Action("🔴  ISSUE CARD", issue); Action("🔵  RETURN CARD", ret); Action("👤  MANAGE ADMINS", admins) } else { Action("🔎  COMPANIES", companies) }
        Spacer(Modifier.height(12.dp)); Text("Company-wise Summary", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Field("Search company / name / card", q) { q = it }
        Spacer(Modifier.height(6.dp)); visible.take(30).forEach { c -> Card(Modifier.fillMaxWidth().padding(vertical = 3.dp).clickable { openCard(c) }) { Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(c.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold); Text("${c.cardNumber}  •  ${c.company}"); Text(c.department) }; StatusBadge(c.status) } } }
        Spacer(Modifier.height(8.dp)); OutlinedButton(companies, Modifier.fillMaxWidth()) { Text("VIEW ALL COMPANIES") }
    }
}

@Composable private fun CompaniesScreen(cards: List<CardRecord>, back: () -> Unit, select: (String) -> Unit) {
    var q by remember { mutableStateOf("") }
    val summaries = cards.groupBy { it.company.trim() }.map { (name, list) -> CompanySummary(name, list.size, list.count { it.status == "AVAILABLE" }, list.count { it.status == "OUT" }) }.filter { it.name.contains(q, true) }.sortedBy { it.name.lowercase() }
    ScreenHeader("Companies", back)
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) { Field("Search company...", q) { q = it }; Spacer(Modifier.height(8.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(summaries) { s -> Card(Modifier.fillMaxWidth().clickable { select(s.name) }) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Text(s.name, fontWeight = FontWeight.Bold); Text("Total ${s.total} • Available ${s.available} • Out ${s.out}") } } } } } }
}

@Composable private fun CompanyScreen(company: String, cards: List<CardRecord>, back: () -> Unit, open: (CardRecord) -> Unit) {
    ScreenHeader(company, back); Column(Modifier.fillMaxSize().padding(horizontal = 16.dp)) { Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) { Stat("Total", cards.size); Stat("Available", cards.count { it.status == "AVAILABLE" }); Stat("Out", cards.count { it.status == "OUT" }) }; Spacer(Modifier.height(10.dp)); LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) { items(cards) { c -> Card(Modifier.fillMaxWidth().clickable { open(c) }) { Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.SpaceBetween) { Column(Modifier.weight(1f)) { Text(c.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold); Text(c.cardNumber); Text("${c.department.ifBlank { "Department not set" }} • ${c.phone.ifBlank { "Mobile not set" }}") }; StatusBadge(c.status) } } } } } }
}

@Composable private fun CardDetailsScreen(card: CardRecord?, history: List<EventRecord>, back: () -> Unit, admin: Boolean, db: FirebaseFirestore, done: (String) -> Unit) {
    var showDeleteConfirm by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf(false) }
    ScreenHeader("Card Details", back)
    if (card == null) { Text("Card not found", Modifier.padding(16.dp)); return }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(card.name.ifBlank { "Name not set" }, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    StatusBadge(card.status)
                }
                Text("Card Number: ${card.cardNumber}")
                Text("Company: ${card.company}")
                Text("Department: ${card.department.ifBlank { "-" }}")
                Text("Mobile: ${card.phone.ifBlank { "-" }}")
                Text("Remarks: ${card.note.ifBlank { "-" }}")
            }
        }
        Spacer(Modifier.height(12.dp))
        if (admin) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
                Button({
                    if (card.status == "AVAILABLE") {
                        val ref = db.collection("cards").document(card.id)
                        ref.update("status", "OUT", "outAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp())
                            .addOnSuccessListener {
                                db.collection("card_events").add(mapOf("cardId" to card.id, "cardNumber" to card.cardNumber, "name" to card.name, "company" to card.company, "action" to "ISSUE", "by" to nowBy(), "at" to FieldValue.serverTimestamp()))
                                    .addOnSuccessListener { done("Card issued"); back() }
                                    .addOnFailureListener { done("Card issued, but history save failed: ${it.message ?: "unknown"}") }
                            }
                            .addOnFailureListener { done(it.message ?: "Issue failed") }
                    } else done("Card already OUT")
                }, Modifier.weight(1f)) { Text("ISSUE CARD") }
                Button({
                    if (card.status == "OUT") {
                        val ref = db.collection("cards").document(card.id)
                        ref.update("status", "AVAILABLE", "depositAt", FieldValue.serverTimestamp(), "updatedAt", FieldValue.serverTimestamp(), "reminderDueAt", null)
                            .addOnSuccessListener {
                                db.collection("card_events").add(mapOf("cardId" to card.id, "cardNumber" to card.cardNumber, "name" to card.name, "company" to card.company, "action" to "RETURN", "by" to nowBy(), "at" to FieldValue.serverTimestamp()))
                                    .addOnSuccessListener { done("Card returned"); back() }
                                    .addOnFailureListener { done("Card returned, but history save failed: ${it.message ?: "unknown"}") }
                            }
                            .addOnFailureListener { done(it.message ?: "Return failed") }
                    } else done("Card already AVAILABLE")
                }, Modifier.weight(1f)) { Text("RETURN CARD") }
            }
            Spacer(Modifier.height(8.dp))
            Button(
                onClick = { if (!deleting) showDeleteConfirm = true },
                enabled = !deleting,
                modifier = Modifier.fillMaxWidth().height(50.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))
            ) { Text(if (deleting) "DELETING..." else "🗑  DELETE CARD PERMANENTLY") }
            Text("Only Admin can permanently delete a card. Its history is kept for audit.", fontSize = 12.sp, color = Color.Gray)
        }
        Spacer(Modifier.height(16.dp)); Text("History", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp))
        LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
            items(history) { e -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(e.action, fontWeight = FontWeight.Bold); Text(fmt(e.at)); Text("By: ${e.by.ifBlank { "Unknown" }}"); Text("Person: ${e.name}") } } }
        }
    }
    if (showDeleteConfirm) {
        AlertDialog(
            onDismissRequest = { if (!deleting) showDeleteConfirm = false },
            title = { Text("Delete card permanently?") },
            text = { Text("Card ${card.cardNumber} will be removed from the active cards permanently. Its history will remain for audit. This cannot be undone.") },
            confirmButton = {
                TextButton(enabled = !deleting, onClick = {
                    deleting = true
                    val ref = db.collection("cards").document(card.id)
                    db.runTransaction { tx ->
                        val snap = tx.get(ref)
                        if (!snap.exists()) throw IllegalStateException("Card already deleted")
                        tx.set(db.collection("card_events").document(), mapOf(
                            "cardId" to card.id,
                            "cardNumber" to card.cardNumber,
                            "name" to card.name,
                            "company" to card.company,
                            "action" to "DELETE",
                            "by" to nowBy(),
                            "at" to FieldValue.serverTimestamp()
                        ))
                        tx.delete(ref)
                    }.addOnSuccessListener {
                        deleting = false
                        showDeleteConfirm = false
                        done("Card permanently deleted")
                        back()
                    }.addOnFailureListener {
                        deleting = false
                        done(it.message ?: "Delete failed")
                    }
                }) { Text("DELETE", color = Color(0xFFB3261E), fontWeight = FontWeight.Bold) }
            },
            dismissButton = { TextButton(enabled = !deleting, onClick = { showDeleteConfirm = false }) { Text("CANCEL") } }
        )
    }
}

@Composable private fun AddCardScreen(db: FirebaseFirestore, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var number by remember { mutableStateOf("") }; var company by remember { mutableStateOf("") }; var dept by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }; var saving by remember { mutableStateOf(false) }
    Form("ADD CARD", back) {
        if (!admin) { Text("Viewer cannot add cards."); return@Form }
        Field("Person Name *", name) { name=it }; Field("Card Number *", number) { number=it }; Field("Company *", company) { company=it }; Field("Department", dept) { dept=it }; Field("Mobile Number", phone) { phone=it }; Field("Remarks", note) { note=it }
        Button({
            if (saving) return@Button
            if (number.isBlank()||company.isBlank()||name.isBlank()) { done("Name, card number and company required"); return@Button }
            saving = true
            val cardNo = number.trim(); val person = name.trim(); val comp = company.trim()
            db.collection("cards").whereEqualTo("cardNumber",cardNo).limit(1).get().addOnSuccessListener {
                if (!it.isEmpty) { saving=false; done("Card number already exists") }
                else {
                    val ref=db.collection("cards").document()
                    ref.set(mapOf("name" to person,"phone" to phone.trim(),"cardNumber" to cardNo,"company" to comp,"department" to dept.trim(),"status" to "AVAILABLE","note" to note.trim(),"createdAt" to FieldValue.serverTimestamp(),"updatedAt" to FieldValue.serverTimestamp()))
                        .addOnSuccessListener {
                            db.collection("card_events").add(mapOf("cardId" to ref.id,"cardNumber" to cardNo,"name" to person,"company" to comp,"action" to "ADD","by" to nowBy(),"at" to FieldValue.serverTimestamp()))
                                .addOnSuccessListener { saving=false; done("Card added successfully"); back() }
                                .addOnFailureListener { saving=false; done("Card saved, but history save failed: ${it.message ?: "unknown"}") }
                        }
                        .addOnFailureListener { saving=false; done(it.message ?: "Card save failed") }
                }
            }.addOnFailureListener { saving=false; done(it.message ?: "Duplicate check failed") }
        }, enabled=!saving, modifier=Modifier.fillMaxWidth().height(52.dp)) { Text(if (saving) "SAVING..." else "ADD CARD") }
    }
}

@Composable private fun IssueScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }; var name by remember { mutableStateOf("") }; var phone by remember { mutableStateOf("") }; var hours by remember { mutableStateOf("24") }
    val selected = cards.firstOrNull { it.cardNumber.equals(number.trim(), true) }
    LaunchedEffect(selected?.id) { if (selected != null) { name = selected.name; phone = selected.phone } }
    Form("ISSUE CARD", back) { if (!admin) { Text("Viewer cannot issue cards."); return@Form }; Field("Card Number *", number) { number=it }; if (selected != null) Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(12.dp)) { Text(selected.name, fontWeight=FontWeight.Bold); Text("${selected.cardNumber} • ${selected.company}"); Text("${selected.department} • ${selected.phone}"); StatusBadge(selected.status) } }; Field("Issue To (Person Name) *", name) { name=it }; Field("Mobile Number", phone) { phone=it }; Text("Reminder after", fontWeight=FontWeight.Bold); Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) { listOf("24","48","72").forEach { h -> FilterChip(hours==h,{hours=h},label={Text("${h}h")}) } }; Button({ val c=cards.firstOrNull { it.cardNumber.equals(number.trim(),true) }; if(c==null) done("Card not found") else if(c.status=="OUT") done("Card already OUT") else { val due=Timestamp(Date(System.currentTimeMillis()+hours.toLong()*3600000)); val ref=db.collection("cards").document(c.id); db.runTransaction { tx -> val s=tx.get(ref); if(s.getString("status")!="AVAILABLE") throw IllegalStateException("Card is not available"); tx.update(ref,mapOf("status" to "OUT","name" to name.trim(),"phone" to phone.trim(),"outAt" to FieldValue.serverTimestamp(),"reminderDueAt" to due,"updatedAt" to FieldValue.serverTimestamp())); tx.set(db.collection("card_events").document(),mapOf("cardId" to c.id,"cardNumber" to c.cardNumber,"name" to name.trim(),"company" to c.company,"action" to "ISSUE","by" to nowBy(),"at" to FieldValue.serverTimestamp(),"reminderHours" to hours.toInt())) }.addOnSuccessListener { done("Card issued"); back() }.addOnFailureListener { done(it.message ?: "Issue failed") } } }, Modifier.fillMaxWidth().height(52.dp)) { Text("ISSUE / CARD OUT") } }
}

@Composable private fun ReturnScreen(db: FirebaseFirestore, cards: List<CardRecord>, admin: Boolean, done: (String) -> Unit, back: () -> Unit) {
    var number by remember { mutableStateOf("") }; val selected=cards.firstOrNull { it.cardNumber.equals(number.trim(),true) }
    Form("RETURN CARD", back) { if(!admin){Text("Viewer cannot return cards.");return@Form}; Field("Card Number *",number){number=it}; if(selected!=null) Card(Modifier.fillMaxWidth()){Column(Modifier.padding(12.dp)){Text(selected.name,fontWeight=FontWeight.Bold);Text("${selected.cardNumber} • ${selected.company}");Text("${selected.department} • ${selected.phone}");StatusBadge(selected.status)}}; Button({val c=cards.firstOrNull{it.cardNumber.equals(number.trim(),true)};if(c==null)done("Card not found")else if(c.status!="OUT")done("Card is already AVAILABLE")else{val ref=db.collection("cards").document(c.id);db.runTransaction{tx->val s=tx.get(ref);if(s.getString("status")!="OUT")throw IllegalStateException("Card is not OUT");tx.update(ref,mapOf("status" to "AVAILABLE","depositAt" to FieldValue.serverTimestamp(),"updatedAt" to FieldValue.serverTimestamp(),"reminderDueAt" to null));tx.set(db.collection("card_events").document(),mapOf("cardId" to c.id,"cardNumber" to c.cardNumber,"name" to (s.getString("name")?:c.name),"company" to c.company,"action" to "RETURN","by" to nowBy(),"at" to FieldValue.serverTimestamp()))}.addOnSuccessListener{done("Card returned; reminder stopped");back()}.addOnFailureListener{done(it.message?:"Return failed")}},Modifier.fillMaxWidth().height(52.dp)){Text("RETURN / DEPOSIT")}}
}

@Composable private fun HistoryScreen(events: List<EventRecord>, open: (EventRecord)->Unit) { var q by remember{mutableStateOf("")}; val list=events.filter{q.isBlank()||listOf(it.name,it.cardNumber,it.company,it.action).any{s->s.contains(q,true)}}; Column(Modifier.fillMaxSize().padding(16.dp)){Text("History",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Field("Search name, card no. or company",q){q=it};Spacer(Modifier.height(8.dp));LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(list){e->Card(Modifier.fillMaxWidth().clickable{open(e)}){Column(Modifier.padding(12.dp)){Text("${e.name.ifBlank{"Unknown"}}  •  ${e.cardNumber}",fontWeight=FontWeight.Bold);Text("${e.action} • ${e.company}");Text(fmt(e.at));Text("By: ${e.by.ifBlank{"Unknown"}}")}}}}}}

@Composable private fun ReportsScreen(cards: List<CardRecord>) { val summaries=cards.groupBy{it.company}.map{(n,l)->CompanySummary(n,l.size,l.count{it.status=="AVAILABLE"},l.count{it.status=="OUT"})}.sortedBy{it.name};Column(Modifier.fillMaxSize().padding(16.dp)){Text("Reports",style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);Spacer(Modifier.height(8.dp));Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){Stat("Total",cards.size);Stat("Available",cards.count{it.status=="AVAILABLE"});Stat("Out",cards.count{it.status=="OUT"})};Spacer(Modifier.height(14.dp));Text("Company-wise Summary",style=MaterialTheme.typography.titleLarge,fontWeight=FontWeight.Bold);LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(summaries){s->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(14.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(s.name,fontWeight=FontWeight.Bold);Text("Total ${s.total} • Available ${s.available} • Out ${s.out}")}}}}}}

@Composable private fun AdminManagementScreen(db: FirebaseFirestore, admin: Boolean, done: (String)->Unit, back:()->Unit){var email by remember{mutableStateOf("")};var users by remember{mutableStateOf(listOf<ManagedUser>())};fun load(){db.collection("email_roles").get().addOnSuccessListener{s->users=s.documents.map{ManagedUser(it.getString("email")?:it.id,it.getString("role")?:"VIEWER")}.sortedBy{it.email}}};LaunchedEffect(admin){if(admin)load()};Form("MANAGE ADMINS",back){if(!admin){Text("Only Admin can manage users.");return@Form};Field("Email Address",email){email=it};Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){Button({val e=email.trim().lowercase(Locale.ENGLISH);if(!Patterns.EMAIL_ADDRESS.matcher(e).matches())done("Valid email required")else db.collection("email_roles").document(emailKey(e)).set(mapOf("email" to e,"role" to "ADMIN","updatedAt" to FieldValue.serverTimestamp())).addOnSuccessListener{done("Admin assigned");email="";load()}},Modifier.weight(1f)){Text("MAKE ADMIN")};OutlinedButton({val e=email.trim().lowercase(Locale.ENGLISH);if(!Patterns.EMAIL_ADDRESS.matcher(e).matches())done("Valid email required")else db.collection("email_roles").document(emailKey(e)).set(mapOf("email" to e,"role" to "VIEWER","updatedAt" to FieldValue.serverTimestamp())).addOnSuccessListener{done("Viewer assigned");email="";load()}},Modifier.weight(1f)){Text("VIEWER")}};Spacer(Modifier.height(12.dp));users.forEach{u->Card(Modifier.fillMaxWidth()){Row(Modifier.fillMaxWidth().padding(12.dp),horizontalArrangement=Arrangement.SpaceBetween){Text(u.email);Text(u.role,fontWeight=FontWeight.Bold)}}}}

@Composable private fun ScreenHeader(title:String,back:()->Unit){Row(Modifier.fillMaxWidth().padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Text(title,style=MaterialTheme.typography.headlineSmall,fontWeight=FontWeight.Bold);TextButton(back){Text("BACK")}}}
@Composable private fun Stat(title:String,value:Int){Card(Modifier.weight(1f),shape=RoundedCornerShape(16.dp)){Column(Modifier.padding(12.dp)){Text(title);Text(value.toString(),fontSize=30.sp,fontWeight=FontWeight.Bold)}}}
@Composable private fun Action(text:String,click:()->Unit){Button(click,Modifier.fillMaxWidth().height(52.dp).padding(vertical=2.dp),shape=RoundedCornerShape(28.dp)){Text(text,fontWeight=FontWeight.Bold)}}
@Composable private fun StatusBadge(status:String){Surface(shape=RoundedCornerShape(20.dp),color=if(status=="OUT")Color(0xFFFFD9DE) else Color(0xFFD8F5DF)){Text(if(status=="OUT")"OUT":"AVAILABLE",Modifier.padding(horizontal=10.dp,vertical=5.dp),fontWeight=FontWeight.Bold,fontSize=12.sp)}}
@Composable private fun Form(title:String,back:()->Unit,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxSize().padding(16.dp),verticalArrangement=Arrangement.spacedBy(10.dp)){ScreenHeader(title,back);Column(Modifier.fillMaxWidth(),verticalArrangement=Arrangement.spacedBy(10.dp),content=content)}}
@Composable private fun Field(label:String,value:String,onChange:(String)->Unit){OutlinedTextField(value,onChange,label={Text(label)},singleLine=true,modifier=Modifier.fillMaxWidth())}
