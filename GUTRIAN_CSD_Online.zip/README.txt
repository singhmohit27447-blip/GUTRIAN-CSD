GUTRIAN CSD - Online Firebase Web App
1) Upload index.html to a static hosting service (Firebase Hosting requires CLI; phone-only users can use a static hosting service with a browser upload).
2) In Firebase Authentication enable Phone.
3) In Firestore create the database.
4) IMPORTANT: Configure Firestore security rules before real use.
5) Phone OTP works only when the hosted domain is added to Firebase Authentication > Settings > Authorized domains.
Note: automatic SMS and background push reminders require an SMS provider / Firebase Cloud Messaging + server-side scheduling. This build records reminderDueAt and is ready for that next step.
